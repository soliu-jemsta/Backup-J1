import { useAuth } from '../../context/AuthContext';
import { BASE_URL } from '../../config';
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import PageHeader from '../shared/PageHeader';
import AdminTable, { AdminTr, AdminTd, ActionButtons } from '../shared/AdminTable';
import Modal from '../shared/Modal';
import { FormInput, FormSelect, FormFilePicker, GoogleAddressInput, ModalActions } from '../shared/FormFields';
import { useToast } from '../shared/ToastProvider';


// const BASE_URL = 'http://127.0.0.1:8000/api';

const emptyForm = {
  name: '', address: '', rent_amount: '', management_rate: '',
  landlord: '', manager: '', listing_type: '',
};

const parseResponse = async (response) => {
  const text = await response.text();
  let data;
  try { data = text ? JSON.parse(text) : null; } catch { data = text; }
  if (!response.ok) {
    const error = new Error('Request failed');
    error.data = data;
    throw error;
  }
  return data;
};

const Property = () => {
  const { authFetch } = useAuth();
  const navigate = useNavigate();
  const { showSuccess, showError } = useToast();

  const [properties, setProperties] = useState([]);
  const [landlords,  setLandlords]  = useState([]);
  const [managers,   setManagers]   = useState([]);
  const [loading,    setLoading]    = useState(true);
  const [error,      setError]      = useState(null);
  const [showModal,  setShowModal]  = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [form,       setForm]       = useState(emptyForm);
  const [formErrors, setFormErrors] = useState({});
  const [images,        setImages]        = useState([]);
  const [imagesLoading, setImagesLoading] = useState(false);
  const [uploadingImage, setUploadingImage] = useState(false);

  useEffect(() => {
    Promise.all([
      authFetch(`${BASE_URL}/properties/properties/`).then(r => { if (!r.ok) throw new Error(`Server error: ${r.status}`); return r.json(); }),
      authFetch(`${BASE_URL}/landlords/`).then(r => r.json()).catch(() => []),
      authFetch(`${BASE_URL}/users/users/`).then(r => r.json()).catch(() => []),
    ])
      .then(([propsData, llData, usersData]) => {
        console.log('Fetched properties:', propsData);
        setProperties(Array.isArray(propsData) ? propsData : []);
        setLandlords(Array.isArray(llData) ? llData : []);
        // Filter managers: staff users (new role-based system)
        const mgrs = Array.isArray(usersData)
          ? usersData.filter(u => u.role === 'staff')
          : [];
        setManagers(mgrs);
        setLoading(false);
      })
      .catch(err => { setError(err.message); setLoading(false); });
  }, []);

  const openAdd = () => {
    setEditingItem(null);
    setForm(emptyForm);
    setFormErrors({});
    setImages([]);
    setShowModal(true);
  };

  const openEdit = (p) => {
    setEditingItem(p);
    setForm({
      name:            p.name            || '',
      address:         p.address         || '',
      rent_amount:     p.rent_amount     || '',
      management_rate: p.management_rate || '',
      landlord:        p.landlord        != null ? String(p.landlord) : '',
      manager:         p.manager         != null ? String(p.manager)  : '',
      listing_type: p.listing_type || ''
    });
    setFormErrors({});
    setImages([]);
    setShowModal(true);
    fetchImages(p.id);
  };

  const closeModal = () => { setShowModal(false); setEditingItem(null); setImages([]); };

  // Mirrors the confirmed /projects/projects/{id}/images/ pattern — not explicitly
  // confirmed for properties, so double-check this path if uploads 404.
  const fetchImages = (propertyId) => {
    setImagesLoading(true);
    authFetch(`${BASE_URL}/properties/properties/${propertyId}/images/`)
      .then(r => r.ok ? r.json() : [])
      .then(data => setImages(Array.isArray(data) ? data : []))
      .catch(() => setImages([]))
      .finally(() => setImagesLoading(false));
  };

  const handleImageUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file || !editingItem) return;
    setUploadingImage(true);
    try {
      const body = new FormData();
      body.append('image', file);
      const res = await authFetch(`${BASE_URL}/properties/properties/${editingItem.id}/images/`, {
        method: 'POST',
        body,
      });
      if (!res.ok) throw new Error(`Upload failed (${res.status})`);
      showSuccess('Image uploaded');
      fetchImages(editingItem.id);
      authFetch(`${BASE_URL}/properties/properties/${editingItem.id}/`)
        .then(r => r.ok ? r.json() : null)
        .then(updated => { if (updated) setProperties(prev => prev.map(p => p.id === updated.id ? updated : p)); })
        .catch(() => {});
    } catch (err) {
      showError(err.message);
    } finally {
      setUploadingImage(false);
      e.target.value = '';
    }
  };

  const handleImageDelete = async (imageId) => {
    if (!window.confirm('Remove this image?')) return;
    try {
      const res = await authFetch(`${BASE_URL}/properties/property-images/${imageId}/`, { method: 'DELETE' });
      if (!res.ok && res.status !== 204) throw new Error(`Delete failed (${res.status})`);
      setImages(prev => prev.filter(img => img.id !== imageId));
      if (editingItem) {
        authFetch(`${BASE_URL}/properties/properties/${editingItem.id}/`)
          .then(r => r.ok ? r.json() : null)
          .then(updated => { if (updated) setProperties(prev => prev.map(p => p.id === updated.id ? updated : p)); })
          .catch(() => {});
      }
    } catch (err) {
      showError(err.message);
    }
  };
  const set = (field) => (e) => setForm(prev => ({ ...prev, [field]: e.target.value }));
  const setAddress = (val) => setForm(prev => ({ ...prev, address: val }));

  const buildBody = () => ({
    name:            form.name,
    address:         form.address,
    rent_amount:     form.rent_amount     || null,
    management_rate: form.management_rate || null,
    landlord:        form.landlord  ? Number(form.landlord)  : null,
    manager:         form.manager   ? Number(form.manager)   : null,
    listing_type: form.listing_type || ''
  });

  const handleSubmit = () => {
    setFormErrors({});
    const url    = editingItem ? `${BASE_URL}/properties/properties/${editingItem.id}/` : `${BASE_URL}/properties/properties/`;
    const method = editingItem ? 'PUT' : 'POST';

    authFetch(url, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(buildBody()),
    })
      .then(parseResponse)
      .then(result => {
        showSuccess(editingItem ? 'Property updated successfully' : 'Property created successfully');
        setProperties(prev =>
          editingItem
            ? prev.map(p => p.id === result.id ? result : p)
            : [...prev, result]
        );
        closeModal();
      })
      .catch(err => {
        showError(err.message);
        if (err.data && typeof err.data === 'object') setFormErrors(err.data);
        else setFormErrors({ general: err.message });
      });
  };

  const handleDelete = (id) => {
    if (!window.confirm('Delete this property?')) return;
    authFetch(`${BASE_URL}/properties/properties/${id}/`, { method: 'DELETE' })
      .then(parseResponse)
      .then(() => {
        showSuccess('Property deleted successfully');
        setProperties(prev => prev.filter(p => p.id !== id));
      })
      .catch(err => { showError(err.message); });
  };

  const fmtDate = (d) => {
    if (!d) return '—';
    return new Date(d).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
  };

  // Landlords no longer have a top-level `name` — build a display name from members' contacts.
  const landlordName = (id) => {
    const ll = landlords.find(l => l.id === id);
    if (!ll) return id != null ? `#${id}` : '—';
    const names = (ll.members || [])
      .map(m => [m.contact?.first_name, m.contact?.last_name].filter(Boolean).join(' '))
      .filter(Boolean);
    return names.join(' & ') || `Landlord #${ll.id}`;
  };

  const managerName = (id) => {
    const m = managers.find(u => u.id === id);
    if (!m) return id != null ? `#${id}` : '—';
    return [m.first_name, m.last_name].filter(Boolean).join(' ') || m.username;
  };

  if (loading) return (
    <div className="flex items-center justify-center py-20 text-gray-500">
      <svg className="animate-spin h-6 w-6 mr-3 text-primaryGreen" viewBox="0 0 24 24" fill="none">
        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
      </svg>
      Loading properties...
    </div>
  );

  if (error) return (
    <div className="flex items-center justify-center py-20 text-red-500">
      ⚠️ Failed to load properties: {error}
    </div>
  );

  const landlordOptions  = landlords.map(l => ({ value: String(l.id), label: landlordName(l.id) }));
  const managerOptions   = managers.map(m  => ({
    value: String(m.id),
    label: [m.first_name, m.last_name].filter(Boolean).join(' ') || m.username || `User #${m.id}`,
  }));
  const listingOptions = [{label: "Rent", value : "rent"}, {label: "Sales", value: "sales"}]

  return (
    <div>
      <PageHeader title="Property" buttonLabel="Add Property" onButtonClick={openAdd} />

      {properties.length === 0 ? (
        <div className="bg-white border rounded-lg py-16 text-center text-gray-400">
          No properties found
        </div>
      ) : (
        <AdminTable columns={[
          'S/N', 'ID', 'Property Name', 'Address', 'Landlord',
          'Manager', 'Rent Amount', 'Mgmt Rate', 'Created At', 'Action',
        ]}>
          {properties.map((p, i) => (
            <AdminTr key={p.id}>
              <AdminTd>{i + 1}</AdminTd>
              <AdminTd>{p.id}</AdminTd>

              <AdminTd>
                <span className="text-primaryGreen font-medium cursor-pointer hover:underline"
                  onClick={() => navigate(`/admin/property/${p.id}`)}>
                  {p.name}
                </span>
              </AdminTd>

              <AdminTd>{p.address || '—'}</AdminTd>
              <AdminTd>{landlordName(p.landlord)}</AdminTd>
              <AdminTd>{managerName(p.manager)}</AdminTd>
              <AdminTd>{p.rent_amount ? `£${p.rent_amount}` : '—'}</AdminTd>
              <AdminTd>{p.management_rate ? `${p.management_rate}%` : '—'}</AdminTd>
              <AdminTd>{fmtDate(p.created_at)}</AdminTd>

              <AdminTd>
                <ActionButtons onEdit={() => openEdit(p)} onDelete={() => handleDelete(p.id)} />
              </AdminTd>
            </AdminTr>
          ))}
        </AdminTable>
      )}

      {showModal && (
        <Modal onClose={closeModal}>
          {formErrors.general && (
            <div className="bg-red-50 border border-red-200 text-red-600 px-3 py-2 rounded mb-4">
              {formErrors.general}
            </div>
          )}
          <div className="grid grid-cols-2 gap-x-6 gap-y-5">
            <FormInput label="Property Name:" placeholder="Enter property name" value={form.name} onChange={set('name')} error={formErrors.name?.[0]} />
            <FormInput label="Rent Amount:" placeholder="e.g. 1500.00" value={form.rent_amount} onChange={set('rent_amount')} error={formErrors.rent_amount?.[0]} />
            <FormInput label="Management Rate (%):" placeholder="e.g. 10.00" value={form.management_rate} onChange={set('management_rate')} error={formErrors.management_rate?.[0]} />
            <div className="col-span-2">
              <GoogleAddressInput
                label="Address:"
                value={form.address}
                onChange={setAddress}
                error={formErrors.address?.[0]}
              />
            </div>
            <FormSelect
              label="Landlord:"
              placeholder="Select Landlord"
              value={form.landlord}
              onChange={set('landlord')}
              options={landlordOptions}
              error={formErrors.landlord?.[0]}
            />
            <FormSelect
              label="Manager:"
              placeholder="Select Manager"
              value={form.manager}
              onChange={set('manager')}
              options={managerOptions}
              error={formErrors.manager?.[0]}
            />
            <FormSelect
              label="Listing Type:"
              placeholder="Select listing"
              value={form.listing_type}
              onChange={set('listing_type')}
              options={listingOptions}
              error={formErrors.listing_type?.[0]}
            />
          </div>
          <ModalActions onCancel={closeModal} onSubmit={handleSubmit} />
        </Modal>
      )}
    </div>
  );
};

export default Property;