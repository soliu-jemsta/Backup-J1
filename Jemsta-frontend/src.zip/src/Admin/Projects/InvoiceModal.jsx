import React, { useRef, useState } from 'react';

// Requires: npm install html2pdf.js
import html2pdf from 'html2pdf.js';

const fmtGBP = (n) => `£${(parseFloat(n) || 0).toFixed(2)}`;
const fmtDate = (d) => d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });

const landlordDisplay = (landlord) => {
  if (!landlord) return { name: '—', address: '—' };
  const primary = landlord.members?.find(m => m.is_primary) || landlord.members?.[0];
  const contact = primary?.contact;
  const name = contact ? [contact.first_name, contact.last_name].filter(Boolean).join(' ') : `Landlord #${landlord.id}`;
  return { name: name || `Landlord #${landlord.id}`, address: landlord.correspondence_address || '—' };
};

const InvoiceModal = ({ project, property, landlord, onClose }) => {
  const invoiceRef = useRef(null);
  const [downloading, setDownloading] = useState(false);

  const { name: landlordName, address: landlordAddress } = landlordDisplay(landlord);
  const propertyName = property?.name || (project.property != null ? `Property #${project.property}` : '—');
  const propertyAddress = property?.address || '—';

  const today = new Date();
  const dueDate = new Date(today);
  dueDate.setDate(dueDate.getDate() + 14);

  const invoiceRefNumber = `JPM-${project.id}-${today.getFullYear()}`;

  const cost = Number(project.cost) || 0;
  const vatRate = Number(project.vat_rate_snapshot) || 0;
  const vatAmount = Number(project.vat_amount) || 0;
  const maintenanceFee = Number(project.maintenance_fee) || 0;
  const maintenanceRate = Number(project.maintenance_rate_snapshot) || 0;
  const adminFee = Number(project.admin_fee) || 0;
  const adminRate = Number(project.admin_rate_snapshot) || 0;
  const total = Number(project.total) || 0; // backend-computed, authoritative
  const totalDisbursements = 0; // no disbursement data source yet
  const grossCosts = total + totalDisbursements;

  const lineItems = [
    {
      description: project.name,
      net: cost,
      rateLabel: `${vatRate}%`,
      fee: vatAmount,
      gross: cost + vatAmount,
    },
  ];
  if (project.apply_maintenance_fee && maintenanceFee > 0) {
    lineItems.push({
      description: 'Maintenance Fee',
      net: null,
      rateLabel: `${maintenanceRate}%`,
      fee: maintenanceFee,
      gross: maintenanceFee,
    });
  }
  if (adminFee > 0) {
    lineItems.push({
      description: 'Admin Fee',
      net: null,
      rateLabel: `${adminRate}%`,
      fee: adminFee,
      gross: adminFee,
    });
  }

  const handleDownload = async () => {
    setDownloading(true);
    try {
      await html2pdf()
        .set({
          margin: 10,
          filename: `${invoiceRefNumber}.pdf`,
          image: { type: 'jpeg', quality: 0.98 },
          html2canvas: { scale: 2 },
          jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' },
        })
        .from(invoiceRef.current)
        .save();
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/40 flex items-start justify-center overflow-y-auto z-50 py-8">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-3xl">
        <div className="flex items-center justify-between px-6 py-4 border-b">
          <h2 className="text-lg font-semibold text-gray-800">Maintenance Invoice — {project.name}</h2>
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={handleDownload}
              disabled={downloading}
              className="px-4 py-2 text-sm font-medium rounded-lg bg-primaryGreen text-white disabled:opacity-60"
            >
              {downloading ? 'Generating…' : 'Download PDF'}
            </button>
            <button type="button" onClick={onClose} className="text-gray-400 hover:text-gray-600 text-xl leading-none">
              &times;
            </button>
          </div>
        </div>

        {/* Printable area */}
        <div ref={invoiceRef} className="p-10 text-sm text-gray-800">
          <div className="flex items-start justify-between mb-8">
            <div>
              <div className="font-bold text-lg tracking-wide">JPM</div>
            </div>
            <div className="text-center flex-1">
              <p className="font-semibold">JEMSTA Estate Agency</p>
              <p className="text-gray-500">Sales, Lettings &amp; Property Management</p>
              <p className="text-gray-500">Business Development Centre – Ty Cynon, Navigation Park Abercynon</p>
              <p className="text-gray-500">CF45 4SN.</p>
            </div>
            <div className="text-right text-gray-500">
              <p>Email: admin@jemstapm.com</p>
              <p>Office: 01443 842731</p>
              <p>Mobile: 07747 549520</p>
            </div>
          </div>

          <h1 className="text-3xl text-gray-400 text-center mb-8">Maintenance Invoice</h1>

          <div className="grid grid-cols-2 gap-6 mb-6">
            <div>
              <p className="font-semibold mb-1">Bill To:</p>
              <p>{landlordName}</p>
              <p className="text-gray-500">{landlordAddress}</p>
            </div>
            <div>
              <p className="font-semibold mb-1">Property:</p>
              <p>{propertyName}</p>
              <p className="text-gray-500">{propertyAddress}</p>
            </div>
          </div>

          <div className="mb-8 space-y-1">
            <p><span className="font-semibold">Invoice Ref:</span> {invoiceRefNumber}</p>
            <p><span className="font-semibold">Invoice Date:</span> {fmtDate(today)}</p>
            <p><span className="font-semibold">Payment Due:</span> {fmtDate(dueDate)}</p>
          </div>

          <table className="w-full mb-6 border-collapse">
            <thead>
              <tr className="border-b border-gray-800 text-left italic">
                <th className="py-2 font-normal">Date</th>
                <th className="py-2 font-normal">Description</th>
                <th className="py-2 font-normal text-right">Net</th>
                <th className="py-2 font-normal text-right">Vat</th>
                <th className="py-2 font-normal text-right">Fee</th>
                <th className="py-2 font-normal text-right">Gross</th>
              </tr>
            </thead>
            <tbody>
              {lineItems.map((item, idx) => (
                <tr key={idx} className="border-b">
                  <td className="py-2">{fmtDate(today)}</td>
                  <td className="py-2">{item.description}</td>
                  <td className="py-2 text-right">{item.net != null ? fmtGBP(item.net) : '—'}</td>
                  <td className="py-2 text-right">{item.rateLabel}</td>
                  <td className="py-2 text-right">{fmtGBP(item.fee)}</td>
                  <td className="py-2 text-right">{fmtGBP(item.gross)}</td>
                </tr>
              ))}
            </tbody>
          </table>

          <div className="flex justify-end mb-8">
            <div className="w-56 space-y-1">
              <div className="flex justify-between font-semibold">
                <span>TOTALS</span>
                <span>{fmtGBP(total)}</span>
              </div>
            </div>
          </div>

          <p className="font-semibold underline mb-2">DISBURSEMENTS</p>
          <table className="w-full mb-2 border-collapse">
            <thead>
              <tr className="border-b border-gray-800 text-left italic">
                <th className="py-2 font-normal">Date</th>
                <th className="py-2 font-normal">Description</th>
                <th className="py-2 font-normal text-right">Gross</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td className="py-3 text-gray-400 italic" colSpan={3}>No disbursements recorded</td>
              </tr>
            </tbody>
          </table>

          <div className="flex justify-end mb-2">
            <div className="w-56 flex justify-between font-semibold">
              <span>TOTAL DISBURSEMENTS</span>
              <span>{fmtGBP(totalDisbursements)}</span>
            </div>
          </div>

          <div className="flex justify-end mt-6 pt-4 border-t-2 border-gray-800">
            <div className="w-56 flex justify-between font-bold text-base">
              <span>GROSS COSTS</span>
              <span>{fmtGBP(grossCosts)}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default InvoiceModal;