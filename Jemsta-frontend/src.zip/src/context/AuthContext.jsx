import { createContext, useContext, useState, useEffect, useCallback, useRef } from 'react';
import { BASE_URL } from '../config';

const AuthContext = createContext();

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
};

// ─── Token helpers ────────────────────────────────────────────────────────────
const TOKEN_KEYS = { access: 'access_token', refresh: 'refresh_token', user: 'user' };

const saveTokens   = (access, refresh) => {
  localStorage.setItem(TOKEN_KEYS.access, access);
  localStorage.setItem(TOKEN_KEYS.refresh, refresh);
};
const clearTokens  = () => Object.values(TOKEN_KEYS).forEach(k => localStorage.removeItem(k));
const getStoredTokens = () => ({
  access:  localStorage.getItem(TOKEN_KEYS.access),
  refresh: localStorage.getItem(TOKEN_KEYS.refresh),
});

// ─── Map backend role → app role ────────────────────────────────────────────
// Backend `role` is one of: 'staff' | 'landlord' | 'tenant'.
// The admin portal is gated on app-role 'admin', so 'staff' (and any
// superuser/admin-ish value) is treated as 'admin' for routing purposes.
// The raw backend value is kept on the user object (as `role`) for display.
const deriveRole = (backendRole) => {
  const r = String(backendRole || '').toLowerCase();
  if (r === 'landlord') return 'landlord';
  if (r === 'tenant')   return 'tenant';
  return 'admin'; // 'staff', 'admin', 'superuser', or unknown → admin portal
};

const LOGIN_ENDPOINT   = `${BASE_URL}/users/login/`;
const REFRESH_ENDPOINT = `${BASE_URL}/users/token/refresh/`;

// ─── Provider ─────────────────────────────────────────────────────────────────
export const AuthProvider = ({ children }) => {
  const [user,    setUser]    = useState(null);
  const [loading, setLoading] = useState(false);
  const [error,   setError]   = useState(null);
  const refreshTimerRef = useRef(null);

  // Restore session on mount
  useEffect(() => {
    const saved = localStorage.getItem(TOKEN_KEYS.user);
    if (saved) {
      try { setUser(JSON.parse(saved)); } catch { clearTokens(); }
    }
  }, []);

  // Silent token refresh
  const refreshAccessToken = useCallback(async () => {
    const { refresh } = getStoredTokens();
    if (!refresh) throw new Error('No refresh token');

    const res = await fetch(REFRESH_ENDPOINT, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify({ refresh }),
    });

    if (!res.ok) {
      clearTokens();
      setUser(null);
      throw new Error('Session expired. Please log in again.');
    }

    const data = await res.json();
    localStorage.setItem(TOKEN_KEYS.access, data.access);
    return data.access;
  }, []);

  // Authenticated fetch — attaches Bearer token, retries once on 401
  const authFetch = useCallback(async (url, options = {}) => {
    let { access } = getStoredTokens();

    const makeRequest = (token) =>
      fetch(url, {
        ...options,
        headers: {
          'Content-Type': 'application/json',
          ...(options.headers || {}),
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
      });

    let res = await makeRequest(access);

    if (res.status === 401) {
      try {
        access = await refreshAccessToken();
        res    = await makeRequest(access);
      } catch {
        throw new Error('Session expired. Please log in again.');
      }
    }

    return res;
  }, [refreshAccessToken]);

  // Login
  const login = async (username, password) => {
    setLoading(true);
    setError(null);

    try {
      const res  = await fetch(LOGIN_ENDPOINT, {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({ username, password }),
      });

      const data = await res.json();

      if (!res.ok) {
        const msg = data?.detail || data?.non_field_errors?.[0] || data?.message || 'Invalid credentials.';
        throw new Error(msg);
      }

      const { access, refresh } = data;
      if (!access || !refresh) throw new Error('Unexpected response from server.');

      saveTokens(access, refresh);

      // Build the user object — backend returns it directly on login
      const backendUser = data.user ?? data; // some backends nest it, some don't
      const appRole = deriveRole(backendUser.role);

      const fullName = [backendUser.first_name, backendUser.last_name]
        .filter(Boolean)
        .join(' ')
        .trim();

      const loggedInUser = {
        id:          backendUser.id,
        username:    backendUser.username,
        email:       backendUser.email,
        first_name:  backendUser.first_name,
        last_name:   backendUser.last_name,
        name:        fullName || backendUser.username, // convenience display name
        phone:       backendUser.phone,
        is_active:   backendUser.is_active,
        is_staff:    backendUser.is_staff,
        groups:      backendUser.groups ?? [],
        adminRole:   backendUser.role,   // raw backend value: 'staff' | 'landlord' | 'tenant'
        role:        appRole,            // app-level routing role: 'admin' | 'landlord' | 'tenant'
      };

      setUser(loggedInUser);
      localStorage.setItem(TOKEN_KEYS.user, JSON.stringify(loggedInUser));
      return loggedInUser;

    } catch (err) {
      const msg = err.message || 'Login failed. Please try again.';
      setError(msg);
      throw new Error(msg);
    } finally {
      setLoading(false);
    }
  };

  // Logout
  const logout = () => {
    clearTokens();
    setUser(null);
    setError(null);
    if (refreshTimerRef.current) clearTimeout(refreshTimerRef.current);
  };

  const value = {
    user,
    loading,
    error,
    login,
    logout,
    authFetch,
    refreshAccessToken,
    isAuthenticated: !!user,
    isAdmin:    user?.role === 'admin',
    isLandlord: user?.role === 'landlord',
    isTenant:   user?.role === 'tenant',
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};