import React from 'react';
import PolicyModal from './PolicyModal';

const sections = [
  {
    title: 'Introduction',
    body: [
      `This website ("our Site") promotes the business referred to on it. In these conditions, the business will be referred to as 'we' and/or 'our'.`,
      `Use of our Site is on the following terms (the "Terms of Use"). If you do not agree to these Terms of Use, please stop using our Site immediately. By accessing and using our Site you are indicating your acceptance to be bound by these Terms of Use. They are a legal agreement between you and us and can only be amended with our consent. They should be read in conjunction with any details provided on our Site about how our Site operates and the services which are available, including our Privacy & Cookie Policy and Trading Terms (if applicable).`,
      `We reserve the right to change these Terms of Use from time to time without prior notice by changing them on our Site.`,
    ],
  },
  {
    title: 'Accessing our Site',
    body: [
      `We cannot guarantee that our Site will operate continuously or without interruptions or be error-free. You must not attempt to interfere with the proper working of our Site and, in particular, you must not attempt to circumvent security, tamper with, hack into, or otherwise disrupt our Site or any computer system, server, router or any other internet-connected device.`,
      `You are responsible for ensuring that your computer system meets all relevant technical specifications necessary to use our Site and is compatible with our Site. You also understand that we cannot and do not guarantee or warrant that any content on our Site will be free from infection, viruses and/or other code that has contaminating or destructive properties. You are responsible for implementing sufficient procedures and virus checks (including anti-virus and other security checks) to satisfy your particular requirements for the safety and reliability of data input and output.`,
      `From time to time, we may restrict access to certain features or parts of our Site, or our entire Site, to users who have registered with us. If you choose, or you are provided with, a user identification code, password or any other piece of information as part of our security procedures, you must treat such information as confidential, and you must not disclose it to any third party. We have the right to disable any user identification code or password, whether chosen by you or allocated by us, at any time, if in our opinion you have failed to comply with any of the provisions of these Terms of Use.`,
      `We reserve the right, in our discretion, to withdraw, suspend or modify our Site or certain features or parts of our Site with or without notice to you, where we have reason to do so. There may also be times when our Site or certain features or parts of our Site become unavailable, whether on a scheduled or unscheduled basis. You agree that we will not be liable to you or to any third party for any withdrawal, modification, unavailability, suspension or discontinuance of our Site or any service available on or through our Site.`,
    ],
  },
  {
    title: 'Using our Site',
    body: [
      `You must use our Site and the information available from our Site responsibly. No such information may be used for or in connection with any unlawful, immoral or anti-social purpose, or in a manner which is or may be damaging to our name or reputation.`,
      `You cannot use our Site:`,
    ],
    list: [
      'for any unlawful purpose',
      'to send spam',
      "to harm, threaten, abuse or harass another person, or in a way that invades someone's privacy or is (in our reasonable opinion) offensive or is unacceptable or damaging to us, our customers or suppliers",
      "to create, check, confirm, update or amend your own or someone else's databases, records, directories, customer lists, mailing or prospecting lists",
      'to tamper with, update or change any part of our Site',
      'in a way that affects how it is run',
      "in a way that imposes an unreasonable or disproportionably large burden on us or our suppliers' communications and technical systems as determined by us",
      'using any automated means to monitor or copy our Site or its content, or to interfere with or attempt to interfere with how our Site works',
    ],
  },
  {
    title: 'Intellectual property rights',
    body: [
      `All content on our Site including but not limited to text, software, photographs and graphics is protected by copyright. We, or our licensors, own copyright and/or database rights in the selection, coordination, arrangement and enhancement of such content, as well as in the original content. Except as expressly set out in these Terms of Use, nothing in these Terms of Use shall give you any rights in respect of any intellectual property owned by us or our licensors. You shall not assert or attempt to obtain any such rights and you shall not use, copy, reproduce, modify, publish, transmit, participate in the transfer or sale of, create derivative works from, or in any way exploit, our name, trade marks, logos or other proprietary marks, or any of the content of our Site, in whole or in part, except as provided in these Terms of Use.`,
    ],
  },
  {
    title: 'If you provide content for our Site',
    body: [
      `If you provide any material to our Site (for example, by providing ratings and reviews, comments, articles or uploading any other content in any format (including video) (each "User Content") you agree to grant us permission, irrevocably and free of charge, to use the User Content (including adapting it for operational or editorial reasons) in any media worldwide, for our own marketing, research and promotional activities and our internal business purposes which may include providing the User Content to selected third party partners, service providers, social media and networking sites.`,
      `You own your User Content at all times, and you continue to have the right to use it in any way you choose.`,
      `By providing any User Content to our Site you confirm that such User Content:`,
    ],
    list: [
      'is your own original work or you are authorised to provide it to our Site and that you have the right to give us permission to use it for the purposes set out in these Terms of Use',
      'will not contain or promote anything illegal, harmful, misleading, abusive, defamatory (that is, it does not damage someone\'s good reputation) or anything else that might cause widespread offence or bring us or our business partners into disrepute',
      'does not take away or affect any other person\'s privacy rights, contract rights or any other rights',
      'does not contain any virus or other code that may damage, interfere with or otherwise adversely affect the operation of our Site',
      'will, if used to promote your own business or services, clearly and openly state your association with the particular business expressly',
      'will not contain any form of mass-mailing or spam',
    ],
    bodyAfter: [
      `If you do not want to grant us the permissions set out above, please do not provide any material to our Site.`,
      `We have no obligation to publish your User Content on our Site and we retain the right to remove any User Content at any time and for any reason.`,
      `We do not edit, pre-vet or review any User Content displayed on our Site. If you believe that any User Content does not comply with the requirements set out in this paragraph, please notify us immediately. We will then review the User Content and, where we deem it appropriate, remove it within a reasonable time.`,
    ],
  },
  {
    title: 'Our liability',
    body: [
      `Although we hope our Site will be of interest to users, we accept no liability and offer no warranties or conditions in relation to our Site or its content, to the fullest extent such liability can be excluded by law.`,
      `There is no limit to what we and the people who provide our services will be liable for if someone dies or is injured because of our negligence or because we have committed fraud.`,
      `Under no circumstances will we, the owner or operator of our Site, or any other organisation involved in creating, producing, maintaining or distributing our Site be liable, whether in contract, tort (including negligence), breach of a statutory duty, even if foreseeable, for any loss of:`,
    ],
    list: [
      'profits, sales, business, or revenue',
      'business interruption',
      'anticipated savings',
      'business opportunity, goodwill or reputation',
      'use of, or corruption to information',
      'information',
    ],
    bodyAfter: [
      `If we do not keep to these conditions, then we will only be liable for losses you have suffered as a direct result. We are not liable to you for any other losses whether such losses are because we have not kept to our obligations or contract, because of something we have done or not done in negligence, due to defamatory statements or liability for a product or otherwise as a result of:`,
      `• use of, or inability to use, our Site`,
      `• use of or reliance on any content displayed on our Site; any mistake, fault, failure to do something, missing information, or virus on our Site or if it does not work properly because of incidents outside of our control such as (but not limited to) interruptions to communication and networks and circumstances beyond our control`,
      `• theft, destruction of information or someone getting access to our records, programs or services without our permission`,
      `• goods, products, services or information received through or advertised on any website which we link to from our Site`,
    ],
  },
  {
    title: 'General',
    body: [
      `Where our Site contains links to other websites and resources provided by third parties, these links are provided for your information only. We have no control over the contents of those websites or resources.`,
      `Any formal legal notices should be sent to us using the details set out on our Site.`,
      `Failure by us to enforce a right does not result in waiver of such right. You may not assign or transfer your rights under these Terms of Use.`,
      `If any part of these Terms of Use is found to be unenforceable as a matter of law, all other parts of these Terms of Use shall be unaffected and shall remain in force.`,
    ],
  },
  {
    title: 'Governing Law and Jurisdiction',
    body: [
      `These conditions make up the whole agreement between you and us in how you use our Site. If a court decides that a condition is not valid, the rest of the conditions will still apply.`,
      `The laws of England and Wales apply to your use of our Site and these conditions. We control our Site from within the United Kingdom. However, you can get access to our Site from other places around the world. Although these places may have different laws from the laws of England and Wales, by using our Site you agree that the laws of England and Wales will apply to everything relating to you using our Site and you agree to keep to these laws. We have the right to take you to court in the country you live in.`,
    ],
  },
  {
    title: 'How to contact us',
    body: [
      `If you experience problems with our Site or would like to comment on it, please feel free to contact us by using the details set out on our Site.`,
    ],
  },
];

const TOUModal = ({ isOpen, onClose }) => (
  <PolicyModal
    isOpen={isOpen}
    onClose={onClose}
    title="Terms of Use"
    subtitle="Terms governing your use of the Jemsta website"
    intro="Please read these Terms of Use carefully before using our Site. By accessing and using our Site you accept these terms in full."
    sections={sections}
  />
);

export default TOUModal;