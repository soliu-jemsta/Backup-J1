// src/hooks/usePropertyListings.js
//
// Fetches properties from the public properties endpoint, filters by
// `listing_type` ('rent' | 'sale'), and normalizes the API's field names
// into the { image, price, title, beds, baths } shape PropertyCard expects.
//
// API fields per the backend serializer:
//   id, name, address, listing_type, is_vacant, rent_amount, images, created_at
//
// Note: the field list doesn't include `beds`/`baths`. If your serializer
// adds those later, they'll be picked up automatically below — for now they
// fall back to null and PropertyCard should handle that gracefully (or hide
// the field). Same goes for price: rent properties show `rent_amount`,
// sale properties don't have an equivalent field yet in the list you gave me,
// so I fall back to null there too — flag if sale price comes from a
// differently-named field (e.g. `sale_price`).

import { useEffect, useState } from 'react';
import { authFetch } from '../api/auth';
import { useAuth } from '../contextP/AuthContext';

const PROPERTIES_PATH = '/properties/properties/';

function formatCurrency(amount) {
  if (amount == null) return null;
  const num = Number(amount);
  if (Number.isNaN(num)) return null;
  return `£${num.toLocaleString()}`;
}

/**
 * Pulls the first image URL out of `images` regardless of whether each
 * entry is a plain string URL or an object like { image: url }.
 */
function resolveFirstImage(images) {
  if (!Array.isArray(images) || images.length === 0) return null;
  const first = images[0];
  if (typeof first === 'string') return first;
  if (first && typeof first === 'object') {
    return first.image || first.url || first.file || null;
  }
  return null;
}

function normalizeProperty(raw) {
  const isRental = raw.listing_type === 'rent';
  const price = isRental
    ? formatCurrency(raw.rent_amount) && `${formatCurrency(raw.rent_amount)}/mo`
    : formatCurrency(raw.sale_price ?? raw.price);

  return {
    id: raw.id,
    image: resolveFirstImage(raw.images),
    price,
    title: raw.name,
    address: raw.address,
    isVacant: raw.is_vacant,
    listingType: raw.listing_type,
    createdAt: raw.created_at,
    // Not present in the documented field list — left null so PropertyCard
    // can fall back/hide these rather than show "undefined".
    beds: raw.beds ?? null,
    baths: raw.baths ?? null,
  };
}

/**
 * @param {'rent'|'sale'} listingType - which subset of properties to return
 */
export function usePropertyListings(listingType) {
  const { isReady, error: authError } = useAuth();
  const [properties, setProperties] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!isReady) {
      console.log('[usePropertyListings] Waiting on auth isReady...');
      return;
    }

    let mounted = true;
    setIsLoading(true);
    console.log('[usePropertyListings] isReady, fetching', listingType, 'properties');

    authFetch(PROPERTIES_PATH)
      .then(async (res) => {
        if (!res.ok) {
          const text = await res.text().catch(() => '');
          console.error('[usePropertyListings] Bad response:', res.status, text);
          throw new Error(`Failed to load properties: ${res.status} ${res.statusText}`);
        }
        const data = await res.json();
        console.log('[usePropertyListings] Raw response:', data);
        // Handle both a plain array response and a paginated { results: [] } shape.
        const list = Array.isArray(data) ? data : data.results || [];
        return list;
      })
      .then((list) => {
        if (!mounted) return;
        console.log('[usePropertyListings] Items before filter:', list.length);
        const filtered = list
          .filter((item) => item.listing_type === listingType)
          .map(normalizeProperty);
        console.log('[usePropertyListings] Items after filter (', listingType, '):', filtered.length, filtered);
        setProperties(filtered);
        setError(null);
      })
      .catch((err) => {
        console.error('[usePropertyListings] Error:', err);
        if (mounted) setError(err);
      })
      .finally(() => {
        if (mounted) setIsLoading(false);
      });

    return () => {
      mounted = false;
    };
  }, [isReady, listingType]);

  return {
    properties,
    isLoading: isLoading && !authError,
    error: authError || error,
  };
}
