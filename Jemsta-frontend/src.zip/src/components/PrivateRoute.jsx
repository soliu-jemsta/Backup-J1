import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const PrivateRoute = ({ Component, requiredRole = null }) => {
  const { isAuthenticated, user } = useAuth();

  if (!isAuthenticated) {
    return <Navigate to="/" replace />;
  }

  if (requiredRole && user?.role !== requiredRole) {
    const fallback =
      user?.role === 'landlord' ? '/landlord' :
      user?.role === 'tenant'   ? '/tenant'   : '/admin';
    return <Navigate to={fallback} replace />;
  }

  return <Component />;
};

export default PrivateRoute;