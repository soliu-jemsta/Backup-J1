import { useAuth } from '../../context/AuthContext';
import { BASE_URL } from '../../config';
import React, { useState, useEffect } from 'react';
import PageHeader from '../shared/PageHeader';
import AdminTable, { AdminTr, AdminTd, ActionButtons } from '../shared/AdminTable';
import Modal from '../shared/Modal';
import { FormInput, ModalActions } from '../shared/FormFields';
import { useToast } from '../shared/ToastProvider';


// const BASE_URL = 'http://127.0.0.1:8000/api/users';

const emptyForm = { name: '' };

const parseResponse = async (response) => {
  const text = await response.text();
  let data;
  try { data = text ? JSON.parse(text) : null; } catch { data = text; }
  if (!response.ok) {
    const error = new Error('Request failed');
    error.data = data;
    throw error;
  }
  return data;
};

const Roles = () => {
  const { authFetch } = useAuth();
  const { showSuccess, showError } = useToast();

  const [roles, setRoles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [editingRole, setEditingRole] = useState(null);
  const [form, setForm] = useState(emptyForm);
  const [formErrors, setFormErrors] = useState({});

  useEffect(() => {
    authFetch(`${BASE_URL}/users/roles/`)
      .then(r => { if (!r.ok) throw new Error(`Server error: ${r.status}`); return r.json(); })
      .then(data => { console.log('Roles: ', data); setRoles(Array.isArray(data) ? data : []); setLoading(false); })
      .catch(err => { setError(err.message); setLoading(false); });
  }, []);

  const openAdd = () => {
    setEditingRole(null);
    setForm(emptyForm);
    setFormErrors({});
    setShowModal(true);
  };

  const openEdit = (r) => {
    setEditingRole(r);
    setForm({ name: r.name || '' });
    setFormErrors({});
    setShowModal(true);
  };

  const closeModal = () => setShowModal(false);

  const set = (field) => (e) =>
    setForm(prev => ({ ...prev, [field]: e.target.value }));

  const handleSubmit = () => {
    setFormErrors({});

    const url = editingRole
      ? `${BASE_URL}/users/roles/${editingRole.id}/`
      : `${BASE_URL}/users/roles/`;

    const method = editingRole ? 'PUT' : 'POST';

    authFetch(url, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: form.name }),
    })
      .then(parseResponse)
      .then(result => {
        showSuccess(editingRole ? 'Role updated successfully' : 'Role created successfully');

        setRoles(prev =>
          editingRole
            ? prev.map(r => r.id === result.id ? result : r)
            : [...prev, result]
        );

        closeModal();
      })
      .catch(err => {
        showError(err.message);
        if (err.data && typeof err.data === 'object') setFormErrors(err.data);
        else setFormErrors({ general: err.message });
      });
  };

  const handleDelete = (id) => {
    if (!window.confirm('Delete this role?')) return;

    authFetch(`${BASE_URL}/users/roles/${id}/`, { method: 'DELETE' })
      .then(parseResponse)
      .then(() => {
        showSuccess('Role deleted successfully');
        setRoles(prev => prev.filter(r => r.id !== id));
      })
      .catch(err => { showError(err.message); });
  };

  if (loading) return (
    <div className="flex items-center justify-center py-20 text-gray-500">
      <svg className="animate-spin h-6 w-6 mr-3 text-primaryGreen" viewBox="0 0 24 24" fill="none">
        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
      </svg>
      Loading roles...
    </div>
  );

  if (error) return (
    <div className="flex items-center justify-center py-20 text-red-500">
      ⚠️ Failed to load roles: {error}
    </div>
  );

  return (
    <div>
      <PageHeader title="Roles" buttonLabel="Add Role" onButtonClick={openAdd} />

      {roles.length === 0 ? (
        <div className="bg-white border rounded-lg py-16 text-center text-gray-400">
          No roles found
        </div>
      ) : (
        <AdminTable columns={['S/N', 'ID', 'Role Name', 'Action']}>
          {roles.map((r, i) => (
            <AdminTr key={r.id}>
              <AdminTd>{i + 1}</AdminTd>
              <AdminTd>{r.id}</AdminTd>
              <AdminTd>{r.name}</AdminTd>
              <AdminTd>
                <ActionButtons
                  onEdit={() => openEdit(r)}
                  onDelete={() => handleDelete(r.id)}
                />
              </AdminTd>
            </AdminTr>
          ))}
        </AdminTable>
      )}

      {showModal && (
        <Modal onClose={closeModal}>
          {formErrors.general && (
            <div className="bg-red-50 border border-red-200 text-red-600 px-3 py-2 rounded mb-4">
              {formErrors.general}
            </div>
          )}

          <div className="grid grid-cols-2 gap-x-6 gap-y-5">
            <FormInput
              label="Role Name:"
              placeholder="Enter role name"
              value={form.name}
              onChange={set('name')}
              error={formErrors.name?.[0]}
            />
          </div>

          <ModalActions onCancel={closeModal} onSubmit={handleSubmit} />
        </Modal>
      )}
    </div>
  );
};

export default Roles;