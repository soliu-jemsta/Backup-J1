import { useAuth } from '../../context/AuthContext';
import { BASE_URL } from '../../config';
import React, { useState, useEffect, useRef, useMemo } from 'react';
import PageHeader from '../shared/PageHeader';
import AdminTable, { AdminTr, AdminTd } from '../shared/AdminTable';
import Modal from '../shared/Modal';
import { FormSelect, FormInput, ModalActions } from '../shared/FormFields';
import { useToast } from '../shared/ToastProvider';
import JemLogo from '../../assets/imgs/jemstalogoblack.png';


// const BASE_URL = 'http://127.0.0.1:8000/api';

const PLAN_LABELS = {
  full_management: 'Full Management',
  let_only: 'Let Only',
  rent_collection: 'Rent Collection',
};

// ── Period constants ──────────────────────────────────────────────────────────

const CURRENT_YEAR = new Date().getFullYear();

const YEAR_OPTIONS = Array.from({ length: 5 }, (_, i) => {
  const y = CURRENT_YEAR - i;
  return { value: String(y), label: String(y) };
});

const PERIOD_TYPE_OPTIONS = [
  { value: 'monthly', label: 'Monthly' },
  { value: 'quarterly', label: 'Quarterly' },
  { value: 'annually', label: 'Annually' },
];

const MONTH_OPTIONS = [
  { value: '0', label: 'January' }, { value: '1', label: 'February' },
  { value: '2', label: 'March' }, { value: '3', label: 'April' },
  { value: '4', label: 'May' }, { value: '5', label: 'June' },
  { value: '6', label: 'July' }, { value: '7', label: 'August' },
  { value: '8', label: 'September' }, { value: '9', label: 'October' },
  { value: '10', label: 'November' }, { value: '11', label: 'December' },
];

const QUARTER_OPTIONS = [
  { value: '1', label: 'Q1 (Jan – Mar)' }, { value: '2', label: 'Q2 (Apr – Jun)' },
  { value: '3', label: 'Q3 (Jul – Sep)' }, { value: '4', label: 'Q4 (Oct – Dec)' },
];

// ── Period helpers ────────────────────────────────────────────────────────────

const periodMultiplier = (periodType) => {
  if (periodType === 'quarterly') return 3;
  if (periodType === 'annually') return 12;
  return 1;
};

const subPeriodOptions = (periodType) => {
  if (periodType === 'monthly') return MONTH_OPTIONS;
  if (periodType === 'quarterly') return QUARTER_OPTIONS;
  if (periodType === 'annually') return YEAR_OPTIONS;
  return [];
};

const subPeriodLabel = (periodType) => {
  if (periodType === 'monthly') return 'Month:';
  if (periodType === 'quarterly') return 'Quarter:';
  if (periodType === 'annually') return 'Year:';
  return 'Sub-Period:';
};

const resolvePeriodDates = ({ year, periodType, subPeriod }) => {
  if (!periodType || !subPeriod) return { fromDate: null, toDate: null };
  if (periodType === 'monthly') {
    if (!year) return { fromDate: null, toDate: null };
    const y = parseInt(year, 10), m = parseInt(subPeriod, 10);
    const from = new Date(y, m, 1), to = new Date(y, m + 1, 0);
    return { fromDate: from.toISOString().slice(0, 10), toDate: to.toISOString().slice(0, 10) };
  }
  if (periodType === 'quarterly') {
    if (!year) return { fromDate: null, toDate: null };
    const y = parseInt(year, 10), q = parseInt(subPeriod, 10);
    const startMonth = (q - 1) * 3, endMonth = startMonth + 2;
    const from = new Date(y, startMonth, 1), to = new Date(y, endMonth + 1, 0);
    return { fromDate: from.toISOString().slice(0, 10), toDate: to.toISOString().slice(0, 10) };
  }
  if (periodType === 'annually') {
    return { fromDate: `${subPeriod}-01-01`, toDate: `${subPeriod}-12-31` };
  }
  return { fromDate: null, toDate: null };
};

const periodLabel = ({ year, periodType, subPeriod }) => {
  if (!periodType || !subPeriod) return '—';
  if (periodType === 'monthly') {
    const m = MONTH_OPTIONS.find(o => o.value === subPeriod);
    return `${m?.label || ''} ${year}`;
  }
  if (periodType === 'quarterly') {
    const q = QUARTER_OPTIONS.find(o => o.value === subPeriod);
    return `${q?.label || ''} ${year}`;
  }
  if (periodType === 'annually') return `Year ${subPeriod}`;
  return '—';
};

// ── Formatting ────────────────────────────────────────────────────────────────

const fmtGBP = (n) => `£${parseFloat(n || 0).toFixed(2)}`;
const fmtDate = (d) => {
  if (!d) return '—';
  return new Date(d).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
};
const fmtDateShort = (d) => {
  if (!d) return '';
  return new Date(d).toLocaleDateString('en-GB', { day: '2-digit', month: '2-digit', year: 'numeric' });
};

// ── Shared document styles (injected into both HTML documents) ────────────────

const SHARED_STYLES = `
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: Arial, sans-serif; color: #333; background: #f5f5f5; padding: 20px; font-size: 13px; }
  .doc-container {
    max-width: 210mm; width: 100%; margin: 0 auto; background: #fff;
    padding: 16mm 20mm 20mm; box-shadow: 0 0 10px rgba(0,0,0,.1); min-height: 297mm;
  }
  /* ── Header ── */
  .doc-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 24px; }
  .doc-header .logo img { height: 70px; }
  .doc-header .logo svg  { height: 70px; }
  .agency-info { text-align: center; flex: 1; margin: 0 16px; }
  .agency-info h1 { font-size: 16px; margin-bottom: 4px; }
  .agency-info p, .contact-info p { margin: 2px 0; font-size: 11px; }
  .contact-info { text-align: right; min-width: 140px; }
  /* ── Doc title ── */
  .doc-title { font-size: 28px; font-weight: 300; text-align: center; margin: 18px 0 22px; color: #222; }
  /* ── Meta block ── */
  .logo img {  height: 100px; }
  .meta-block { display: flex; justify-content: space-between; margin-bottom: 20px; gap: 10%; }
  .meta-left  { font-size: 13px; }
  .meta-left strong { display: block; margin-bottom: 2px; }
  .meta-right { text-align: right; font-size: 13px; }
  .meta-right .meta-row { display: flex; justify-content: flex-start; gap: 10px; margin-bottom: 3px; }
  .meta-right .meta-label { font-weight: bold; }
  /* ── Borderless-header table ── */
  .ledger-table { width: 100%; border-collapse: collapse; margin-bottom: 20px; font-size: 12px; }
  .ledger-table th {
    padding: 8px 6px; text-align: left; font-style: italic; font-weight: bold;
    border-bottom: 1.5px solid #333; border-top: none; border-left: none; border-right: none;
  }
  .ledger-table th.right, .ledger-table td.right { text-align: right; }
  .ledger-table td { padding: 7px 6px; border: none; vertical-align: top; }
  .ledger-table tr.bold td { font-weight: bold; }
  .ledger-table tr.italic-bold td { font-weight: bold; font-style: italic; }
  .ledger-table tr.section-gap td { padding-top: 14px; }
  /* ── Summary ── */
  .summary-block { margin-left: auto; width: 55%; font-size: 12px; }
  .summary-block .row { display: flex; justify-content: space-between; padding: 4px 0; }
  .summary-block .row.total { font-weight: bold; border-top: 1.5px solid #333; margin-top: 4px; padding-top: 6px; font-size: 13px; }
  /* ── Notes ── */
  .notes { margin-top: 28px; font-size: 11.5px; line-height: 1.7; }
  .notes p { margin: 6px 0; }
  .signature { color: #1a3fa8; font-family: 'Comic Sans MS', cursive; margin-top: 22px; font-size: 16px; }
  .company-footer { text-align: center; margin-top: 30px; font-size: 11px; font-weight: bold; }
  @media print {
    body { background: #fff; padding: 0; }
    .doc-container { box-shadow: none; padding: 14mm 18mm; margin: 0; max-width: none; width: 100%; }
  }
`;

const HEADER_HTML = `
  <div class="logo">
    <img src="${JemLogo}" alt="Jemsta Logo" />
  </div>
  <div class="agency-info">
    <h1>JEMSTA Estate Agency</h1>
    <p>Sales, Lettings &amp; Property Management</p>
    <p>Ty Cynon House, Navigation Park, Abercynon, Mountain Ash, CF45 4SN</p>
  </div>
  <div class="contact-info">
    <p>Web: www.jemsta.co.uk</p>
    <p>Email: admin@jemsta.co.uk</p>
    <p>Office: 01443 842731</p>
    <p>Mobile: 07747549520</p>
  </div>
`;

const FOOTER_HTML = `
  <div class="notes">
    <p>For all queries, please contact the office by emailing admin@jemsta.co.uk or by calling 01443 842731.</p>
    <p><strong>Thank you for your ongoing custom.</strong></p>
    <p class="signature">Jemsta Estate Agency</p>
  </div>
  <div class="company-footer">
    <p>A company registered in England &amp; Wales: 11342464 &nbsp;|&nbsp; VAT Number: 354258295</p>
  </div>
`;

// ── Invoice HTML (page 1) ─────────────────────────────────────────────────────

const genRef = () => `JEA-${Date.now().toString(36).toUpperCase()}`;

const buildInvoiceHTML = ({
  landlord, property, fromDate, toDate,
  managementRate, completedProjects, periodStr,
  monthlyRent, totalRent, multiplier, invoiceRef,
}) => {
  const rate = parseFloat(managementRate || 0);
  const mgmtFee = (totalRent * rate) / 100;
  const totalDisbursements = completedProjects.reduce(
    (s, p) => s + parseFloat(p.actual_cost || p.budget || 0), 0
  );
  const plan = landlord?.plan || '';
  let payable = 0;
  if (plan === 'full_management') payable = totalRent - mgmtFee - totalDisbursements;
  else if (plan === 'rent_collection') payable = totalRent - mgmtFee;
  else payable = totalRent;

  const invoiceDate = new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' });
  const rentDescription = multiplier === 1
    ? `Rental Income – ${property?.name || '—'}`
    : `Rental Income – ${property?.name || '—'} (${multiplier} months × ${fmtGBP(monthlyRent)})`;

  const disbRows = completedProjects.map(p => `
    <tr>
      <td>${fmtDateShort(p.start_date)}</td>
      <td>${p.name}${p.description ? ' — ' + p.description : ''}</td>
      <td class="right">${fmtGBP(p.actual_cost || p.budget)}</td>
    </tr>`).join('');

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <title>Landlord Invoice – ${invoiceRef}</title>
  <style>${SHARED_STYLES}</style>
</head>
<body>
<div class="doc-container">

  <div class="doc-header">${HEADER_HTML}</div>

  <h2 class="doc-title">Landlord Invoice</h2>

  <div class="meta-block">
    <div class="meta-left">
      <strong>${landlord?.name || '—'}</strong>
      ${landlord?.correspondence_address || ''}
    </div>
    <div class="meta-right">
      <div class="meta-row"><span class="meta-label">Invoice Ref:</span><span>${invoiceRef}</span></div>
      <div class="meta-row"><span class="meta-label">Invoice Date:</span><span>${invoiceDate}</span></div>
      <div class="meta-row"><span class="meta-label">Period:</span><span>${periodStr}</span></div>
      <div class="meta-row"><span class="meta-label">Property:</span><span>${property?.name || '—'}</span></div>
      <div class="meta-row"><span class="meta-label">Plan:</span><span>${PLAN_LABELS[plan] || plan || '—'}</span></div>
      <div class="meta-row"><span class="meta-label">Payment Due:</span><span>N/A – Collected from rental</span></div>
    </div>
  </div>

  <!-- Income / Expense Table -->
  <table class="ledger-table">
    <thead>
      <tr>
        <th style="width:18%">Date</th>
        <th>Description</th>
        <th class="right" style="width:13%">Net</th>
        <th class="right" style="width:10%">VAT</th>
        <th class="right" style="width:13%">Gross</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>${fmtDateShort(fromDate)} –<br/>${fmtDateShort(toDate)}</td>
        <td>${rentDescription}<br/><span style="font-size:11px;color:#666">${property?.address || ''}</span></td>
        <td class="right">${fmtGBP(totalRent)}</td>
        <td class="right">0%</td>
        <td class="right">${fmtGBP(totalRent)}</td>
      </tr>
      ${mgmtFee > 0 ? `
      <tr style="display: none">
        <td>${invoiceDate}</td>
        <td>Management Fee (${rate}% of ${fmtGBP(totalRent)})</td>
        <td class="right">-${fmtGBP(mgmtFee)}</td>
        <td class="right">0%</td>
        <td class="right">-${fmtGBP(mgmtFee)}</td>
      </tr>` : ''}
    </tbody>
  </table>

  <!-- Totals -->
  <p style="font-weight:bold;margin-bottom:8px;">TOTALS</p>
  <table class="ledger-table">
    <thead>
      <tr><th>Description</th><th class="right" style="width:20%">Amount</th></tr>
    </thead>
    <tbody>
      ${multiplier > 1 ? `
      <tr>
        <td>Monthly Rent</td>
        <td class="right">${fmtGBP(monthlyRent)} × ${multiplier} months</td>
      </tr>` : ''}
      <tr><td>Gross Rental Income</td><td class="right">${fmtGBP(totalRent)}</td></tr>
      ${mgmtFee > 0 ? `
      <tr><td>Management Fee (${rate}%)</td><td class="right">-${fmtGBP(mgmtFee)}</td></tr>` : ''}
      <tr class="bold section-gap">
        <td>Net Income</td><td class="right">${fmtGBP(totalRent - mgmtFee)}</td>
      </tr>
    </tbody>
  </table>

  ${completedProjects.length > 0 ? `
  <p style="font-weight:bold;margin:18px 0 8px;">DISBURSEMENTS</p>
  <table class="ledger-table">
    <thead>
      <tr>
        <th style="width:18%">Date</th>
        <th>Description</th>
        <th class="right" style="width:18%">Gross</th>
      </tr>
    </thead>
    <tbody>
      ${disbRows}
      <tr class="bold section-gap">
        <td colspan="2">Total Disbursements</td>
        <td class="right">${fmtGBP(totalDisbursements)}</td>
      </tr>
    </tbody>
  </table>` : ''}

  <!-- Summary -->
  <div class="summary-block">
    <div class="row"><span>Gross Costs</span><span>${fmtGBP(mgmtFee)}</span></div>
    ${completedProjects.length > 0
      ? `<div class="row"><span>Gross Disbursements</span><span>${fmtGBP(totalDisbursements)}</span></div>`
      : ''}
    <div class="row total"><span>Total Amount Payable</span><span>${fmtGBP(payable)}</span></div>
  </div>

  ${FOOTER_HTML}

</div>
</body>
</html>`;
};

// ── Rental Statement HTML (page 2) ────────────────────────────────────────────

const buildStatementHTML = ({
  landlord, property, fromDate, toDate,
  managementRate, completedProjects, periodStr,
  monthlyRent, totalRent, multiplier, invoiceRef,
}) => {
  const rate = parseFloat(managementRate || 0);
  const mgmtFee = (totalRent * rate) / 100;
  const totalDisbursements = completedProjects.reduce(
    (s, p) => s + parseFloat(p.actual_cost || p.budget || 0), 0
  );
  const plan = landlord?.plan || '';
  let payable = 0;
  if (plan === 'full_management') payable = totalRent - mgmtFee - totalDisbursements;
  else if (plan === 'rent_collection') payable = totalRent - mgmtFee;
  else payable = totalRent;

  const statementDate = new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });

  // Statement ref format: JEM/LRS/[initials]/[propId]/[seq]
  const initials = (landlord?.name || 'XX').split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2);
  const propId = String(property?.id || '0000').padStart(4, '0');
  const seq = String(Math.floor(Math.random() * 99) + 1).padStart(2, '0');
  const stmtRef = `JEM/LRS/${initials}/${propId}/${seq}`;

  const openingBalance = 0; // always 0 — agency holds no prior balance
  const closingBalance = openingBalance + totalRent - mgmtFee - totalDisbursements;

  // Build ledger rows: income row, then expense rows
  const expenseRows = [];

  if (mgmtFee > 0) {
    expenseRows.push({
      date: statementDate,
      description: `Management Fee (${rate}%)`,
      income: '',
      expend: fmtGBP(mgmtFee),
    });
  }

  completedProjects.forEach(p => {
    expenseRows.push({
      date: fmtDateShort(p.start_date),
      description: `Disbursement – ${p.name}`,
      income: '',
      expend: fmtGBP(p.actual_cost || p.budget),
    });
  });

  const expRowsHTML = expenseRows.map(r => `
    <tr>
      <td>${r.date}</td>
      <td>${r.description}</td>
      <td class="right">${r.income}</td>
      <td class="right">${r.expend}</td>
      <td class="right"></td>
    </tr>`).join('');

  const rentDescription = multiplier === 1
    ? `Rental Income – ${property?.name || '—'}`
    : `Rental Income – ${property?.name || '—'} (${multiplier} months × ${fmtGBP(monthlyRent)})`;

  // Last 4 digits placeholder for bank account
  const bankLast4 = '####';

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <title>Landlord Rental Statement – ${stmtRef}</title>
  <style>${SHARED_STYLES}</style>
</head>
<body>
<div class="doc-container">

  <div class="doc-header">${HEADER_HTML}</div>

  <h2 class="doc-title">Landlord Rental Statement</h2>

  <div class="meta-block">
    <div class="meta-left">
      <strong>${landlord?.name || '—'}</strong>
      ${landlord?.correspondence_address || ''}
    </div>
    <div class="meta-right">
      <div class="meta-row"><span class="meta-label">Statement Date:</span><span>${statementDate}</span></div>
      <div class="meta-row"><span class="meta-label">Statement Ref:</span><span>${stmtRef}</span></div>
      <div class="meta-row"><span class="meta-label">Property:</span><span>${property?.name || property?.address || '—'}</span></div>
      <div class="meta-row"><span class="meta-label">Period:</span><span>${periodStr}</span></div>
    </div>
  </div>

  <!-- Ledger table -->
  <table class="ledger-table">
    <thead>
      <tr>
        <th style="width:16%">Date</th>
        <th>Description</th>
        <th class="right" style="width:14%">Income</th>
        <th class="right" style="width:14%">Expend</th>
        <th class="right" style="width:14%">Balance</th>
      </tr>
    </thead>
    <tbody>
      <!-- Opening Balance -->
      <tr class="bold">
        <td></td>
        <td>Opening Balance</td>
        <td class="right"></td>
        <td class="right"></td>
        <td class="right">${fmtGBP(openingBalance)}</td>
      </tr>

      <!-- Rental income row -->
      <tr>
        <td>${fmtDateShort(fromDate)} –<br/>${fmtDateShort(toDate)}</td>
        <td>${rentDescription}<br/>
          <span style="font-size:11px;color:#555">Invoice Ref: ${invoiceRef}</span>
        </td>
        <td class="right">${fmtGBP(totalRent)}</td>
        <td class="right"></td>
        <td class="right">${fmtGBP(openingBalance + totalRent)}</td>
      </tr>

      ${expRowsHTML}

      <!-- Payment to landlord -->
      <tr style="color:#c00">
        <td>${statementDate}</td>
        <td>Payment to Landlord &nbsp; Invoice: ${invoiceRef}</td>
        <td class="right"></td>
        <td class="right">${fmtGBP(payable)}</td>
        <td class="right"></td>
      </tr>

      <!-- BALANCE row -->
      <tr class="bold section-gap">
        <td></td>
        <td>BALANCE</td>
        <td class="right"></td>
        <td class="right"></td>
        <td class="right">${fmtGBP(closingBalance)}</td>
      </tr>

      <!-- Remitted line -->
      <tr class="italic-bold">
        <td></td>
        <td colspan="3">Remitted to your account ending ${bankLast4} within the next 3–5 working days</td>
        <td class="right">${fmtGBP(payable)}</td>
      </tr>

      <!-- Closing Balance -->
      <tr class="italic-bold">
        <td></td>
        <td>Closing Balance</td>
        <td class="right"></td>
        <td class="right"></td>
        <td class="right">${fmtGBP(closingBalance - payable)}</td>
      </tr>
    </tbody>
  </table>

  ${FOOTER_HTML}

</div>
</body>
</html>`;
};

// ── Combined 2-page print ─────────────────────────────────────────────────────

/**
 * Merges both HTML documents into one printable window.
 * Page 1 = Invoice, Page 2 = Statement.
 * A CSS page-break sits between them so each prints on its own sheet.
 */
const buildCombinedHTML = (invoiceHTML, statementHTML) => {
  // Extract <body> content from each
  const bodyOf = (html) => {
    const m = html.match(/<body[^>]*>([\s\S]*?)<\/body>/i);
    return m ? m[1] : html;
  };
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <title>Jemsta Invoice &amp; Statement</title>
  <style>
    ${SHARED_STYLES}
    .page-break { page-break-after: always; break-after: page; }
  </style>
</head>
<body>
  <div class="page-break">
    ${bodyOf(invoiceHTML)}
  </div>
  ${bodyOf(statementHTML)}
</body>
</html>`;
};

const printDocument = (html) => {
  const win = window.open('', '_blank');
  win.document.write(html);
  win.document.close();
  win.focus();
  setTimeout(() => win.print(), 700);
};

// ── Incomplete-project warning ────────────────────────────────────────────────

const WarningBanner = ({ projects }) => {
  const { authFetch } = useAuth();
  if (!projects.length) return null;
  return (
    <div className="col-span-2 bg-amber-50 border border-amber-300 rounded-lg px-4 py-3 text-sm">
      <div className="flex items-start gap-2">
        <svg className="w-4 h-4 text-amber-500 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
            d="M12 9v2m0 4h.01M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z" />
        </svg>
        <div>
          <p className="font-semibold text-amber-700 mb-1">
            {projects.length} incomplete project{projects.length > 1 ? 's' : ''} found in this period
          </p>
          <ul className="list-disc list-inside text-amber-600 space-y-0.5">
            {projects.map(p => (
              <li key={p.id}>
                <span className="font-medium">{p.name}</span>{' — '}
                <span className="capitalize">{p.status}</span>
                {(p.actual_cost || p.budget) ? ` (${fmtGBP(p.actual_cost || p.budget)})` : ''}
              </li>
            ))}
          </ul>
          <p className="text-amber-600 mt-1.5 italic text-xs">
            Only <strong>completed</strong> projects are included as disbursements.
          </p>
        </div>
      </div>
    </div>
  );
};

// ── Main Page ─────────────────────────────────────────────────────────────────

const emptyForm = {
  landlord_id: '', property_id: '',
  year: String(CURRENT_YEAR),
  period_type: '', sub_period: '', management_rate: '',
};

const InvoicePage = () => {
  const { showSuccess, showError } = useToast();

  const [invoices, setInvoices] = useState([]);
  const [landlords, setLandlords] = useState([]);
  const [properties, setProperties] = useState([]);
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [previewData, setPreviewData] = useState(null); // { invoiceHTML, statementHTML }
  const [showPreview, setShowPreview] = useState(false);
  const [previewPage, setPreviewPage] = useState('invoice'); // 'invoice' | 'statement'
  const [form, setForm] = useState(emptyForm);
  const iframeRef = useRef(null);

  useEffect(() => {
    Promise.all([
      authFetch(`${BASE_URL}/landlords/landlords/`).then(r => r.json()).catch(() => []),
      authFetch(`${BASE_URL}/properties/properties/`).then(r => r.json()).catch(() => []),
      authFetch(`${BASE_URL}/projects/projects/`).then(r => r.json()).catch(() => []),
    ]).then(([ll, props, projs]) => {
      setLandlords(Array.isArray(ll) ? ll : []);
      setProperties(Array.isArray(props) ? props : []);
      setProjects(Array.isArray(projs) ? projs : []);
      setLoading(false);
    }).catch(() => setLoading(false));
  }, []);

  // ── Derived ──────────────────────────────────────────────────────────────

  const isAnnually = form.period_type === 'annually';

  const { fromDate, toDate } = useMemo(() =>
    resolvePeriodDates({ year: form.year, periodType: form.period_type, subPeriod: form.sub_period }),
    [form.year, form.period_type, form.sub_period]
  );

  const multiplier = periodMultiplier(form.period_type);
  const selectedLandlord = landlords.find(l => String(l.id) === form.landlord_id);
  const selectedProperty = properties.find(p => String(p.id) === form.property_id);
  const monthlyRent = parseFloat(selectedProperty?.rent_amount || 0);
  const totalRent = monthlyRent * multiplier;

  const filteredProperties = form.landlord_id
    ? properties.filter(p => String(p.landlord) === form.landlord_id)
    : properties;

  const allPeriodProjects = useMemo(() => {
    if (!fromDate || !toDate || !form.property_id) return [];
    const from = new Date(fromDate), to = new Date(toDate);
    return projects.filter(p => {
      if (String(p.property) !== form.property_id) return false;
      const start = p.start_date ? new Date(p.start_date) : null;
      if (!start) return false;
      const end = p.end_date ? new Date(p.end_date) : start;
      return start <= to && end >= from;
    });
  }, [projects, form.property_id, fromDate, toDate]);

  const completedProjects = allPeriodProjects.filter(p => p.status === 'completed');
  const incompleteProjects = allPeriodProjects.filter(p => p.status !== 'completed');

  // ── Handlers ─────────────────────────────────────────────────────────────

  const set = (field) => (e) => setForm(prev => ({ ...prev, [field]: e.target.value }));

  const handleLandlordChange = (e) =>
    setForm(prev => ({ ...prev, landlord_id: e.target.value, property_id: '', management_rate: '' }));

  const handlePropertyChange = (e) => {
    const pid = e.target.value;
    const prop = properties.find(p => String(p.id) === pid);
    setForm(prev => ({
      ...prev,
      property_id: pid,
      landlord_id: prop?.landlord != null ? String(prop.landlord) : prev.landlord_id,
      management_rate: prop?.management_rate != null ? String(prop.management_rate) : prev.management_rate,
    }));
  };

  const handlePeriodTypeChange = (e) =>
    setForm(prev => ({ ...prev, period_type: e.target.value, sub_period: '' }));

  const handleGenerate = () => {
    if (!form.landlord_id || !form.property_id) {
      showError('Please select a Landlord and a Property.');
      return;
    }
    if (!fromDate || !toDate) {
      showError('Please complete the period selection.');
      return;
    }

    const rate = parseFloat(form.management_rate || 0);
    const mgmtFee = (totalRent * rate) / 100;
    const totalDisb = completedProjects.reduce(
      (s, p) => s + parseFloat(p.actual_cost || p.budget || 0), 0
    );
    const plan = selectedLandlord?.plan || '';
    let payable = 0;
    if (plan === 'full_management') payable = totalRent - mgmtFee - totalDisb;
    else if (plan === 'rent_collection') payable = totalRent - mgmtFee;
    else payable = totalRent;

    const pStr = periodLabel({ year: form.year, periodType: form.period_type, subPeriod: form.sub_period });
    const fullPeriodStr = `${pStr} (${fmtDate(fromDate)} – ${fmtDate(toDate)})`;
    const invoiceRef = genRef();

    const sharedArgs = {
      landlord: selectedLandlord, property: selectedProperty,
      fromDate, toDate, managementRate: form.management_rate,
      completedProjects, periodStr: fullPeriodStr,
      monthlyRent, totalRent, multiplier, invoiceRef,
    };

    const invoiceHTML = buildInvoiceHTML(sharedArgs);
    const statementHTML = buildStatementHTML(sharedArgs);

    setPreviewData({ invoiceHTML, statementHTML });
    setPreviewPage('invoice');
    setShowModal(false);
    setShowPreview(true);

    setInvoices(prev => [{
      id: prev.length + 1,
      ref: invoiceRef,
      landlord: selectedLandlord?.name || '—',
      property: selectedProperty?.name || '—',
      period: pStr,
      totalRent: fmtGBP(totalRent),
      plan: PLAN_LABELS[plan] || plan || '—',
      generatedAt: new Date().toLocaleDateString('en-GB'),
      invoiceHTML,
      statementHTML,
    }, ...prev]);

    showSuccess('Invoice & Statement generated successfully!');
  };

  // ── Options ───────────────────────────────────────────────────────────────

  const landlordOptions = landlords.map(l => ({ value: String(l.id), label: l.name || `Landlord #${l.id}` }));
  const propertyOptions = filteredProperties.map(p => ({ value: String(p.id), label: p.name || `Property #${p.id}` }));
  const subOptions = subPeriodOptions(form.period_type);

  // ── Render ────────────────────────────────────────────────────────────────

  const currentPreviewHTML = previewData
    ? (previewPage === 'invoice' ? previewData.invoiceHTML : previewData.statementHTML)
    : '';

  return (
    <div>
      <PageHeader
        title="Invoices"
        buttonLabel="Generate Invoice"
        onButtonClick={() => { setForm(emptyForm); setShowModal(true); }}
      />

      {/* ── Invoice table ──────────────────────────────────────────────── */}
      {loading ? (
        <div className="flex items-center justify-center py-20 text-gray-500">
          <svg className="animate-spin h-6 w-6 mr-3 text-primaryGreen" viewBox="0 0 24 24" fill="none">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
          </svg>
          Loading...
        </div>
      ) : invoices.length === 0 ? (
        <div className="bg-white border rounded-lg py-16 text-center text-gray-400">
          No invoices generated yet. Click <strong>Generate Invoice</strong> to create one.
        </div>
      ) : (
        <AdminTable columns={['S/N', 'Ref', 'Landlord', 'Property', 'Period', 'Total Rent', 'Plan', 'Date', 'Action']}>
          {invoices.map((inv, i) => (
            <AdminTr key={inv.id}>
              <AdminTd>{i + 1}</AdminTd>
              <AdminTd><span className="font-mono text-xs">{inv.ref}</span></AdminTd>
              <AdminTd>{inv.landlord}</AdminTd>
              <AdminTd>{inv.property}</AdminTd>
              <AdminTd>{inv.period}</AdminTd>
              <AdminTd>{inv.totalRent}</AdminTd>
              <AdminTd>
                <span className="px-2 py-1 rounded-full text-xs font-semibold bg-green-100 text-primaryGreen">
                  {inv.plan}
                </span>
              </AdminTd>
              <AdminTd>{inv.generatedAt}</AdminTd>
              <AdminTd>
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => { setPreviewData({ invoiceHTML: inv.invoiceHTML, statementHTML: inv.statementHTML }); setPreviewPage('invoice'); setShowPreview(true); }}
                    className="px-2 py-1 text-xs font-medium border border-primaryGreen text-primaryGreen rounded-lg hover:bg-green-50 transition-colors"
                  >
                    Invoice
                  </button>
                  <button
                    onClick={() => { setPreviewData({ invoiceHTML: inv.invoiceHTML, statementHTML: inv.statementHTML }); setPreviewPage('statement'); setShowPreview(true); }}
                    className="px-2 py-1 text-xs font-medium border border-blue-500 text-blue-600 rounded-lg hover:bg-blue-50 transition-colors"
                  >
                    Statement
                  </button>
                  <button
                    onClick={() => printDocument(buildCombinedHTML(inv.invoiceHTML, inv.statementHTML))}
                    className="px-2 py-1 text-xs font-medium bg-primaryGreen text-white rounded-lg hover:bg-green-800 transition-colors"
                  >
                    PDF
                  </button>
                </div>
              </AdminTd>
            </AdminTr>
          ))}
        </AdminTable>
      )}

      {/* ── Generate Modal ─────────────────────────────────────────────── */}
      {showModal && (
        <Modal onClose={() => setShowModal(false)}>
          <h2 className="text-lg font-semibold text-gray-800 mb-6">Generate Invoice</h2>
          <div className="grid grid-cols-2 gap-x-6 gap-y-5">

            <FormSelect label="Landlord:" placeholder="Select Landlord"
              value={form.landlord_id} onChange={handleLandlordChange} options={landlordOptions} />

            <FormSelect
              label="Property:"
              placeholder={form.landlord_id ? 'Select Property' : 'Select a landlord first'}
              value={form.property_id} onChange={handlePropertyChange} options={propertyOptions}
            />

            <div className="col-span-2">
              <FormSelect label="Period:" placeholder="Select Period Type"
                value={form.period_type} onChange={handlePeriodTypeChange} options={PERIOD_TYPE_OPTIONS} />
            </div>

            {/* Year — hidden when Annually (sub_period acts as the year) */}
            {form.period_type && !isAnnually && (
              <FormSelect label="Year:" placeholder="Select Year"
                value={form.year} onChange={set('year')} options={YEAR_OPTIONS} />
            )}

            {/* Sub-period: Month / Quarter / Year */}
            {form.period_type && (
              <FormSelect
                label={subPeriodLabel(form.period_type)}
                placeholder={`Select ${subPeriodLabel(form.period_type).replace(':', '')}`}
                value={form.sub_period} onChange={set('sub_period')} options={subOptions}
              />
            )}

            {fromDate && toDate && (
              <p className="col-span-2 text-xs text-gray-400 -mt-2">
                Covers: {fmtDate(fromDate)} – {fmtDate(toDate)}
              </p>
            )}

            <div className="col-span-2">
              <FormInput label="Management Rate (%):" placeholder="e.g. 10"
                type="number" value={form.management_rate} onChange={set('management_rate')} />
              {selectedProperty?.management_rate &&
                form.management_rate === String(selectedProperty.management_rate) && (
                  <p className="text-xs text-green-600 mt-1">
                    ✓ Auto-filled from property ({selectedProperty.management_rate}%)
                  </p>
                )}
            </div>

            <WarningBanner projects={incompleteProjects} />

            {selectedLandlord && selectedProperty && fromDate && toDate && (
              <div className="col-span-2 bg-green-50 border border-green-200 rounded-lg p-4 text-sm">
                <p className="font-medium text-primaryGreen mb-2">Invoice Summary Preview</p>
                <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-gray-700">
                  <span className="text-gray-500">Plan:</span>
                  <span>{PLAN_LABELS[selectedLandlord.plan] || selectedLandlord.plan || '—'}</span>
                  <span className="text-gray-500">Monthly Rent:</span>
                  <span>{fmtGBP(monthlyRent)}</span>
                  {multiplier > 1 && (<>
                    <span className="text-gray-500">Period Multiplier:</span>
                    <span>× {multiplier} months</span>
                  </>)}
                  <span className="text-gray-500 font-medium">{multiplier > 1 ? 'Total Rent:' : 'Rent Amount:'}</span>
                  <span className="font-semibold text-primaryGreen">{fmtGBP(totalRent)}</span>
                  {form.management_rate && (<>
                    <span className="text-gray-500">Management Fee:</span>
                    <span>{fmtGBP((totalRent * parseFloat(form.management_rate)) / 100)} ({form.management_rate}%)</span>
                  </>)}
                  <span className="text-gray-500">Completed Projects:</span>
                  {completedProjects.length > 0
                    ? <span>{completedProjects.map(p => p.name).join(', ')}</span>
                    : <span className="text-gray-400 italic">None in this period</span>}
                  {completedProjects.length > 0 && (<>
                    <span className="text-gray-500">Total Disbursements:</span>
                    <span>{fmtGBP(completedProjects.reduce((s, p) => s + parseFloat(p.actual_cost || p.budget || 0), 0))}</span>
                  </>)}
                </div>
              </div>
            )}

          </div>
          <ModalActions onCancel={() => setShowModal(false)} onSubmit={handleGenerate} submitLabel="Generate" />
        </Modal>
      )}

      {/* ── Preview Panel ───────────────────────────────────────────────── */}
      {showPreview && previewData && (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
          <div className="absolute inset-0 bg-black bg-opacity-50" onClick={() => setShowPreview(false)} />
          <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-4xl mx-4 flex flex-col"
            style={{ height: '90vh' }}>

            {/* Header bar */}
            <div className="flex items-center justify-between px-6 py-3 border-b border-gray-200">
              {/* Page toggle */}
              <div className="flex items-center gap-1 bg-gray-100 rounded-lg p-1">
                <button
                  onClick={() => setPreviewPage('invoice')}
                  className={`px-4 py-1.5 rounded-md text-sm font-medium transition-colors ${previewPage === 'invoice'
                      ? 'bg-white shadow text-primaryGreen'
                      : 'text-gray-500 hover:text-gray-700'
                    }`}
                >
                  Invoice
                </button>
                <button
                  onClick={() => setPreviewPage('statement')}
                  className={`px-4 py-1.5 rounded-md text-sm font-medium transition-colors ${previewPage === 'statement'
                      ? 'bg-white shadow text-blue-600'
                      : 'text-gray-500 hover:text-gray-700'
                    }`}
                >
                  Statement
                </button>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => printDocument(currentPreviewHTML)}
                  className="px-4 py-2 border border-gray-300 text-gray-700 text-sm font-medium rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Print this page
                </button>
                <button
                  onClick={() => printDocument(buildCombinedHTML(previewData.invoiceHTML, previewData.statementHTML))}
                  className="px-4 py-2 bg-primaryGreen hover:bg-green-800 text-white text-sm font-medium rounded-lg transition-colors flex items-center gap-2"
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                      d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                  </svg>
                  Print Both (PDF)
                </button>
                <button
                  onClick={() => setShowPreview(false)}
                  className="p-2 rounded-lg hover:bg-gray-100 text-gray-500 transition-colors"
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>
            </div>

            {/* iframe */}
            <div className="flex-1 overflow-hidden rounded-b-2xl">
              <iframe ref={iframeRef} srcDoc={currentPreviewHTML}
                className="w-full h-full border-0" title="Document Preview" />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default InvoicePage;