import { useAuth } from '../../context/AuthContext';
import { BASE_URL } from '../../config';
import React, { useState, useEffect } from 'react';
import PageHeader from '../shared/PageHeader';
import AdminTable, { AdminTr, AdminTd, ActionButtons } from '../shared/AdminTable';
import Modal from '../shared/Modal';
import { FormInput, FormSelect, FormSpinner, FormTextarea, ModalActions } from '../shared/FormFields';
import { useToast } from '../shared/ToastProvider';


// const BASE_URL = 'http://127.0.0.1:8000/api';

const emptyForm = {
  property: '', landlord: '', manager: '',
  name: '', description: '', budget: '', actual_cost: '',
  start_date: '', end_date: '', status: 'active',
  paymentType: '', paymentMethod: '', projectType: '',
  landlordPermission: '', applyManagementRate: '',
};

const parseResponse = async (response) => {
  const text = await response.text();
  let data;
  try { data = text ? JSON.parse(text) : null; } catch { data = text; }
  if (!response.ok) {
    const error = new Error(
      (data && typeof data === 'object' ? data.detail || JSON.stringify(data) : data) || `Error ${response.status}`
    );
    error.data = data;
    throw error;
  }
  return data;
};

const fmtDate = (d) => {
  if (!d) return '—';
  return new Date(d).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
};

const Projects = () => {
  const { authFetch } = useAuth();
  const { showSuccess, showError } = useToast();

  const [projects,    setProjects]    = useState([]);
  const [properties,  setProperties]  = useState([]);
  const [landlords,   setLandlords]   = useState([]);
  const [managers,    setManagers]    = useState([]);
  const [loading,     setLoading]     = useState(true);
  const [error,       setError]       = useState(null);
  const [showModal,   setShowModal]   = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [form,        setForm]        = useState(emptyForm);
  const [formErrors,  setFormErrors]  = useState({});

  useEffect(() => {
    Promise.all([
      authFetch(`${BASE_URL}/projects/`).then(r => { if (!r.ok) throw new Error(`Server error: ${r.status}`); return r.json(); }),
      authFetch(`${BASE_URL}/properties/`).then(r => r.json()).catch(() => []),
      authFetch(`${BASE_URL}/landlords/`).then(r => r.json()).catch(() => []),
      authFetch(`${BASE_URL}/users/users/`).then(r => r.json()).catch(() => []),
    ])
      .then(([projectsData, propsData, llData, usersData]) => {
        console.log("Projects: ", projectsData);
        setProjects(Array.isArray(projectsData) ? projectsData : []);
        setProperties(Array.isArray(propsData) ? propsData : []);
        setLandlords(Array.isArray(llData) ? llData : []);
        const mgrs = Array.isArray(usersData)
          ? usersData.filter(u => u.role === 'staff')
          : [];
        setManagers(mgrs);
        setLoading(false);
      })
      .catch(err => { setError(err.message); setLoading(false); });
  }, []);

  const openAdd = () => {
    setEditingItem(null);
    setForm(emptyForm);
    setFormErrors({});
    setShowModal(true);
  };

  const openEdit = (p) => {
    setEditingItem(p);
    setForm({
      property:            p.property    != null ? String(p.property)  : '',
      landlord:            p.landlord    != null ? String(p.landlord)  : '',
      manager:             p.manager     != null ? String(p.manager)   : '',
      name:                p.name        || '',
      description:         p.description || '',
      budget:              p.budget      || '',
      actual_cost:         p.actual_cost || '',
      start_date:          p.start_date  || '',
      end_date:            p.end_date    || '',
      status:              p.status      || 'active',
      paymentType:         '',
      paymentMethod:       '',
      projectType:         '',
      landlordPermission:  '',
      applyManagementRate: '',
    });
    setFormErrors({});
    setShowModal(true);
  };

  const closeModal = () => { setShowModal(false); setEditingItem(null); };
  const set = (field) => (e) => setForm(prev => ({ ...prev, [field]: e.target.value }));

  const handlePropertyChange = (e) => {
    const selectedId = e.target.value;
    const selectedProperty = properties.find(p => String(p.id) === selectedId);
    setForm(prev => ({
      ...prev,
      property: selectedId,
      landlord: selectedProperty?.landlord != null ? String(selectedProperty.landlord) : '',
      manager:  selectedProperty?.manager  != null ? String(selectedProperty.manager)  : '',
    }));
  };

  const buildBody = () => ({
    name:        form.name,
    description: form.description,
    property:    form.property    ? Number(form.property)   : null,
    landlord:    form.landlord    ? Number(form.landlord)   : null,
    manager:     form.manager     ? Number(form.manager)    : null,
    budget:      form.budget      || null,
    actual_cost: form.actual_cost || null,
    start_date:  form.start_date  || null,
    end_date:    form.end_date    || null,
    status:      form.status      || 'active',
  });

  const handleSubmit = async () => {
    setFormErrors({});
    const url    = editingItem ? `${BASE_URL}/projects/${editingItem.id}/` : `${BASE_URL}/projects/`;
    const method = editingItem ? 'PUT' : 'POST';

    try {
      const result = await authFetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(buildBody()),
      }).then(parseResponse);

      showSuccess(editingItem ? 'Project updated successfully' : 'Project created successfully');
      setProjects(prev =>
        editingItem
          ? prev.map(p => p.id === result.id ? result : p)
          : [...prev, result]
      );
      closeModal();
    } catch (err) {
      showError(err.message);
      if (err.data && typeof err.data === 'object') setFormErrors(err.data);
      else setFormErrors({ general: err.message });
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this project?')) return;
    try {
      await authFetch(`${BASE_URL}/projects/${id}/`, { method: 'DELETE' }).then(parseResponse);
      showSuccess('Project deleted successfully');
      setProjects(prev => prev.filter(p => p.id !== id));
    } catch (err) {
      showError(err.message);
    }
  };

  const propertyName = (id) => properties.find(p => p.id === id)?.name  || (id != null ? `#${id}` : '—');
  const landlordName = (id) => landlords.find(l => l.id === id)?.name   || (id != null ? `#${id}` : '—');
  const managerName  = (id) => {
    const m = managers.find(m => m.id === id);
    if (!m) return id != null ? `#${id}` : '—';
    return [m.first_name, m.last_name].filter(Boolean).join(' ') || m.username;
  };

  const propertyOptions = properties.map(p => ({ value: String(p.id), label: p.name || `Property #${p.id}` }));
  const landlordOptions = landlords.map(l  => ({ value: String(l.id), label: l.name || `Landlord #${l.id}` }));
  const managerOptions  = managers.map(m   => ({
    value: String(m.id),
    label: [m.first_name, m.last_name].filter(Boolean).join(' ') || m.username || `User #${m.id}`,
  }));

  if (loading) return (
    <div className="flex items-center justify-center py-20 text-gray-500">
      <svg className="animate-spin h-6 w-6 mr-3 text-primaryGreen" viewBox="0 0 24 24" fill="none">
        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
      </svg>
      Loading projects...
    </div>
  );

  if (error) return (
    <div className="flex items-center justify-center py-20 text-red-500">
      ⚠️ Failed to load projects: {error}
    </div>
  );

  const statusBadge = (status) => {
    const styles = {
      active:    'bg-green-100 text-primaryGreen',
      completed: 'bg-blue-100 text-blue-700',
      pending:   'bg-yellow-100 text-yellow-700',
      cancelled: 'bg-red-100 text-red-600',
    };
    return (
      <span className={`px-2 py-1 rounded-full text-xs font-semibold capitalize ${styles[status] || 'bg-gray-100 text-gray-600'}`}>
        {status || '—'}
      </span>
    );
  };

  return (
    <div>
      <PageHeader title="Projects" buttonLabel="Add Project" onButtonClick={openAdd} />

      {projects.length === 0 ? (
        <div className="bg-white border rounded-lg py-16 text-center text-gray-400">
          No projects found
        </div>
      ) : (
        <AdminTable columns={[
          'S/N', 'ID', 'Project Name', 'Property', 'Landlord', 'Manager',
          'Budget', 'Actual Cost', 'Start Date', 'End Date', 'Status', 'Action',
        ]}>
          {projects.map((p, i) => (
            <AdminTr key={p.id}>
              <AdminTd>{i + 1}</AdminTd>
              <AdminTd>{p.id}</AdminTd>
              <AdminTd>
                <span className="text-primaryGreen font-medium">{p.name}</span>
              </AdminTd>
              <AdminTd>{propertyName(p.property)}</AdminTd>
              <AdminTd>{landlordName(p.landlord)}</AdminTd>
              <AdminTd>{managerName(p.manager)}</AdminTd>
              <AdminTd>{p.budget   ? `£${p.budget}`      : '—'}</AdminTd>
              <AdminTd>{p.actual_cost ? `£${p.actual_cost}` : '—'}</AdminTd>
              <AdminTd>{fmtDate(p.start_date)}</AdminTd>
              <AdminTd>{fmtDate(p.end_date)}</AdminTd>
              <AdminTd>{statusBadge(p.status)}</AdminTd>
              <AdminTd>
                <ActionButtons onEdit={() => openEdit(p)} onDelete={() => handleDelete(p.id)} />
              </AdminTd>
            </AdminTr>
          ))}
        </AdminTable>
      )}

      {showModal && (
        <Modal onClose={closeModal}>
          {formErrors.general && (
            <div className="bg-red-50 border border-red-200 text-red-600 px-3 py-2 rounded mb-4">
              {formErrors.general}
            </div>
          )}
          <div className="grid grid-cols-2 gap-x-6 gap-y-5">
            <FormSelect
              label="Property:"
              placeholder="Select Property"
              value={form.property}
              onChange={handlePropertyChange}
              options={propertyOptions}
              error={formErrors.property?.[0]}
            />
            <FormInput
              label="Project Name:"
              placeholder="Enter project name"
              value={form.name}
              onChange={set('name')}
              error={formErrors.name?.[0]}
            />

            <div className="col-span-2">
              <FormTextarea
                label="Description:"
                placeholder="Enter description"
                value={form.description}
                onChange={set('description')}
                rows={4}
              />
              {formErrors.description?.[0] && (
                <span className="text-xs text-red-500">{formErrors.description[0]}</span>
              )}
            </div>

            {/* Landlord — auto-filled from selected property, read-only */}
            <div className="flex flex-col gap-1.5">
              <label className="text-sm font-medium text-gray-800">Landlord:</label>
              <div className="w-full px-4 py-2.5 border border-gray-200 rounded-lg text-sm bg-gray-50 text-gray-500 cursor-not-allowed">
                {form.landlord ? landlordName(Number(form.landlord)) : 'Auto-filled on property select'}
              </div>
            </div>

            {/* Manager — auto-filled from selected property, read-only */}
            <div className="flex flex-col gap-1.5">
              <label className="text-sm font-medium text-gray-800">Manager:</label>
              <div className="w-full px-4 py-2.5 border border-gray-200 rounded-lg text-sm bg-gray-50 text-gray-500 cursor-not-allowed">
                {form.manager ? managerName(Number(form.manager)) : 'Auto-filled on property select'}
              </div>
            </div>

            <FormSpinner
              label="Budget:"
              placeholder="Enter budget"
              value={form.budget}
              onChange={set('budget')}
            />
            <FormSpinner
              label="Actual Cost:"
              placeholder="Enter actual cost"
              value={form.actual_cost}
              onChange={set('actual_cost')}
            />

            <FormInput label="Start Date:" type="date" value={form.start_date} onChange={set('start_date')} error={formErrors.start_date?.[0]} />
            <FormInput label="End Date:"   type="date" value={form.end_date}   onChange={set('end_date')}   error={formErrors.end_date?.[0]} />

            <FormSelect
              label="Status:"
              placeholder="Select Status"
              value={form.status}
              onChange={set('status')}
              options={[
                { value: 'active',    label: 'Active'    },
                { value: 'pending',   label: 'Pending'   },
                { value: 'completed', label: 'Completed' },
                { value: 'cancelled', label: 'Cancelled' },
              ]}
              error={formErrors.status?.[0]}
            />
            <FormSelect
              label="Landlord Permission Granted:"
              placeholder="Select"
              value={form.landlordPermission}
              onChange={set('landlordPermission')}
              options={[{ value: 'yes', label: 'Yes' }, { value: 'no', label: 'No' }]}
            />
          </div>
          <ModalActions onCancel={closeModal} onSubmit={handleSubmit} />
        </Modal>
      )}
    </div>
  );
};

export default Projects;