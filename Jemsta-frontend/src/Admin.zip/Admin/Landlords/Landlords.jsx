import { useAuth } from '../../context/AuthContext';
import { BASE_URL } from '../../config';
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import PageHeader from '../shared/PageHeader';
import AdminTable, { AdminTr, AdminTd, ActionButtons } from '../shared/AdminTable';
import Modal from '../shared/Modal';
import { FormInput, FormSelect, GoogleAddressInput, ModalActions } from '../shared/FormFields';
import { useToast } from '../shared/ToastProvider';


// const BASE_URL = 'http://127.0.0.1:8000/api';

// Django choices — update labels here if the backend changes
const LANDLORD_TYPES = [
  { value: 'Sole',        label: 'Sole'        },
  { value: 'Joint',       label: 'Joint'       },
  { value: 'Company',     label: 'Company'     },
  { value: 'Trust',       label: 'Trust'       },
];

const PLAN_OPTIONS = [
  { value: 'full_management',  label: 'Full Management'  },
  { value: 'let_only',         label: 'Let Only'         },
  { value: 'rent_collection',  label: 'Rent Collection'  },
];

const emptyForm = {
  name: '', email: '', phone: '', password: '',
  address: '', account_number: '',
  manager_id: '', type: '', plan: '', status: '',
};

const parseResponse = async (response) => {
  const text = await response.text();
  let data;
  try { data = text ? JSON.parse(text) : null; } catch { data = text; }
  if (!response.ok) {
    const error = new Error('Request failed');
    error.data = data;
    throw error;
  }
  return data;
};

const Landlords = () => {
  const { authFetch } = useAuth();
  const navigate = useNavigate();
  const { showSuccess, showError } = useToast();

  const [landlords,   setLandlords]   = useState([]);
  const [managers,    setManagers]    = useState([]);
  const [loading,     setLoading]     = useState(true);
  const [error,       setError]       = useState(null);
  const [showModal,   setShowModal]   = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [form,        setForm]        = useState(emptyForm);
  const [formErrors,  setFormErrors]  = useState({});

  useEffect(() => {
    Promise.all([
      authFetch(`${BASE_URL}/landlords/`).then(r => { if (!r.ok) throw new Error(`Server error: ${r.status}`); return r.json(); }),
      authFetch(`${BASE_URL}/users/users/`).then(r => r.json()).catch(() => []),
    ])
      .then(([llData, usersData]) => {
        console.log("LL Data: ", llData);
        setLandlords(Array.isArray(llData) ? llData : []);
        const mgrs = Array.isArray(usersData)
          ? usersData.filter(u => u.role === 'staff')
          : [];
        setManagers(mgrs);
        setLoading(false);
      })
      .catch(err => { setError(err.message); setLoading(false); });
  }, []);

  const openAdd = () => {
    setEditingItem(null);
    setForm(emptyForm);
    setFormErrors({});
    setShowModal(true);
  };

  const openEdit = (l) => {
    setEditingItem(l);
    setForm({
      name:           l.name                   || '',
      email:          l.primary_email          || '',
      phone:          l.phone                  || '',
      password:       '',
      address:        l.correspondence_address || '',
      account_number: l.account_number         || '',
      manager_id:     l.manager_id  != null    ? String(l.manager_id) : '',
      type:           l.type                   || '',
      plan:           l.plan                   || '',
      status:         l.rsw_status             ? 'Active' : 'Inactive',
    });
    setFormErrors({});
    setShowModal(true);
  };

  const closeModal = () => { setShowModal(false); setEditingItem(null); };
  const set = (field) => (e) => setForm(prev => ({ ...prev, [field]: e.target.value }));
  const setAddress = (val) => setForm(prev => ({ ...prev, address: val }));

  const buildBody = () => {
    const body = {
      name:                   form.name,
      primary_email:          form.email,
      phone:                  form.phone,
      correspondence_address: form.address        || null,
      account_number:         form.account_number || null,
      type:                   form.type           || null,
      plan:                   form.plan           || null,
      rsw_status:             form.status === 'Active',
    };
    // manager is optional — only send if selected
    if (form.manager_id) body.manager = Number(form.manager_id);
    if (form.password)   body.password = form.password;
    return body;
  };

  const handleSubmit = () => {
    setFormErrors({});
    const url    = editingItem
      ? `${BASE_URL}/landlords/${editingItem.id}/`
      : `${BASE_URL}/landlords/`;
    const method = editingItem ? 'PUT' : 'POST';

    authFetch(url, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(buildBody()),
    })
      .then(parseResponse)
      .then(result => {
        showSuccess(editingItem ? 'Landlord updated successfully' : 'Landlord created successfully');
        setLandlords(prev =>
          editingItem
            ? prev.map(l => l.id === result.id ? result : l)
            : [...prev, result]
        );
        closeModal();
      })
      .catch(err => {
        showError(err.message);
        if (err.data && typeof err.data === 'object') setFormErrors(err.data);
        else setFormErrors({ general: err.message });
      });
  };

  const handleDelete = (id) => {
    if (!window.confirm('Delete this landlord?')) return;
    authFetch(`${BASE_URL}/landlords/${id}/`, { method: 'DELETE' })
      .then(parseResponse)
      .then(() => {
        showSuccess('Landlord deleted successfully');
        setLandlords(prev => prev.filter(l => l.id !== id));
      })
      .catch(err => { showError(err.message); });
  };

  const managerName  = (id) => {
    const m = managers.find(m => m.id === id);
    if (!m) return id != null ? `#${id}` : '—';
    return [m.first_name, m.last_name].filter(Boolean).join(' ') || m.username;
  };
  const planLabel    = (val) => PLAN_OPTIONS.find(p => p.value === val)?.label || val || '—';
  const managerOptions = managers.map(m => ({
    value: String(m.id),
    label: [m.first_name, m.last_name].filter(Boolean).join(' ') || m.username || `User #${m.id}`,
  }));

  if (loading) return (
    <div className="flex items-center justify-center py-20 text-gray-500">
      <svg className="animate-spin h-6 w-6 mr-3 text-primaryGreen" viewBox="0 0 24 24" fill="none">
        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
      </svg>
      Loading landlords...
    </div>
  );

  if (error) return (
    <div className="flex items-center justify-center py-20 text-red-500">
      ⚠️ Failed to load landlords: {error}
    </div>
  );

  return (
    <div>
      <PageHeader title="Landlord" buttonLabel="Add Landlord" onButtonClick={openAdd} />

      {landlords.length === 0 ? (
        <div className="bg-white border rounded-lg py-16 text-center text-gray-400">
          No landlords found
        </div>
      ) : (
        <AdminTable columns={[
          'S/N', 'ID', 'Name', 'LL Type', 'Plan', 'Email', 'Phone',
          'Address', 'Account Number', 'Manager', 'AML Status',
          'Failed Checks', 'Outstanding Checks', 'Compliance Status', 'Status', 'Action',
        ]}>
          {landlords.map((l, i) => (
            <AdminTr key={l.id}>
              <AdminTd>{i + 1}</AdminTd>
              <AdminTd>{l.id}</AdminTd>

              <AdminTd>
                <span
                  className="text-primaryGreen font-medium cursor-pointer hover:underline"
                  onClick={() => navigate(`/admin/landlords/${l.id}`)}
                >
                  {l.name}
                </span>
              </AdminTd>

              <AdminTd>{l.type        || '—'}</AdminTd>
              <AdminTd>{planLabel(l.plan)}</AdminTd>
              <AdminTd>{l.primary_email || '—'}</AdminTd>
              <AdminTd>{l.phone        || '—'}</AdminTd>
              <AdminTd>{l.correspondence_address || '—'}</AdminTd>
              <AdminTd>{l.account_number || '—'}</AdminTd>
              <AdminTd>{managerName(l.manager_id)}</AdminTd>
              <AdminTd>{l.rsw_status ? 'OK' : 'Pending'}</AdminTd>
              <AdminTd>—</AdminTd>
              <AdminTd>—</AdminTd>
              <AdminTd>—</AdminTd>

              <AdminTd>
                <span className={`px-2 py-1 rounded-full text-xs font-semibold ${
                  l.rsw_status ? 'bg-green-100 text-primaryGreen' : 'bg-yellow-100 text-yellow-700'
                }`}>
                  {l.rsw_status ? 'Active' : 'Inactive'}
                </span>
              </AdminTd>

              <AdminTd>
                <ActionButtons onEdit={() => openEdit(l)} onDelete={() => handleDelete(l.id)} />
              </AdminTd>
            </AdminTr>
          ))}
        </AdminTable>
      )}

      {showModal && (
        <Modal onClose={closeModal}>
          {formErrors.general && (
            <div className="col-span-2 bg-red-50 border border-red-200 text-red-600 px-3 py-2 rounded mb-2">
              {formErrors.general}
            </div>
          )}
          <div className="grid grid-cols-2 gap-x-6 gap-y-5">

            <FormInput
              label="Name:"
              placeholder="Enter full name"
              value={form.name}
              onChange={set('name')}
              error={formErrors.name?.[0]}
            />
            <FormInput
              label="Email:"
              placeholder="Enter email address"
              type="email"
              value={form.email}
              onChange={set('email')}
              error={formErrors.primary_email?.[0]}
            />
            <FormInput
              label="Phone Number:"
              placeholder="Enter phone number"
              value={form.phone}
              onChange={set('phone')}
              error={formErrors.phone?.[0]}
            />
            {/* <FormInput
              label="Password:"
              placeholder={editingItem ? 'Leave blank to keep current' : 'Enter password'}
              type="password"
              value={form.password}
              onChange={set('password')}
              error={formErrors.password?.[0]}
            /> */}
            <FormInput
              label="Account Number:"
              placeholder="Enter bank account number"
              value={form.account_number}
              onChange={set('account_number')}
              error={formErrors.account_number?.[0]}
            />
            <FormSelect
              label="Manager:"
              placeholder="Select Manager"
              value={form.manager_id}
              onChange={set('manager_id')}
              options={managerOptions}
              error={formErrors.manager_id?.[0]}
            />
            <FormSelect
              label="Landlord Type:"
              placeholder="Select Type"
              value={form.type}
              onChange={set('type')}
              options={LANDLORD_TYPES}
              error={formErrors.type?.[0]}
            />
            <FormSelect
              label="Plan:"
              placeholder="Select Plan"
              value={form.plan}
              onChange={set('plan')}
              options={PLAN_OPTIONS}
              error={formErrors.plan?.[0]}
            />

            <div className="col-span-2">
              <GoogleAddressInput
                label="Address:"
                value={form.address}
                onChange={setAddress}
                error={formErrors.correspondence_address?.[0]}
              />
            </div>

            <FormSelect
              label="Status:"
              placeholder="Select Status"
              value={form.status}
              onChange={set('status')}
              options={[{ value: 'Active', label: 'Active' }, { value: 'Inactive', label: 'Inactive' }]}
              error={formErrors.rsw_status?.[0]}
            />

          </div>
          <ModalActions onCancel={closeModal} onSubmit={handleSubmit} />
        </Modal>
      )}
    </div>
  );
};

export default Landlords;